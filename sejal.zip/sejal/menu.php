<body data-spy="scroll" data-target=".fixed-top">

    <!-- Navigation -->
    <div class="sejal-navigation">
        <nav class="navbar navbar-expand-lg fixed-top navbar-light">
            <div class="container">

                <a class="navbar-brand logo-image" href="index.php"><img src="images/logo.png" alt="alternative"></a>

                <button class="navbar-toggler p-0 border-0" type="button" data-toggle="offcanvas">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link page-scroll" href="#header">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link page-scroll" href="#intro">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link page-scroll" href="#features">Features</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link page-scroll" href="#services">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link page-scroll" href="#contact">Contact us</a>
                        </li>
                    </ul>
                    <span class="nav-item">
                        <a class="btn-solid-sm page-scroll" href="#contact">Hire Now</a>
                    </span>
                </div>

            </div>

        </nav>

    </div>