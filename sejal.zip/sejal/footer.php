<!-- Footer -->
<div class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-12 col-sm-12 col-12">
                <div class="footer-col">
                    <h6>About Sejal Detective Agency</h6>
                   
                </div>
                <ul class="list-unstyled li-space-lg p-small">
                        <li><b>Address :</b> <a class="page-scroll" href="#">Be part of the story and follow us on Twitter </a></li>
                        <li><b>Number :</b> <a class="page-scroll" href="#">+91-456-345-8678</a></li>
                        <li><b>E-mail : </b><a class="page-scroll" href="#">support@sejaldetectiveagencuy.com</a></li>
                       
                    </ul>
                <div class="footer-col third">
                    <span class="fa-stack">
                        <a href="#">
                            <i class="fas fa-circle fa-stack-2x"></i>
                            <i class="fab fa-facebook-f fa-stack-1x"></i>
                        </a>
                    </span>
                    <span class="fa-stack">
                        <a href="#">
                            <i class="fas fa-circle fa-stack-2x"></i>
                            <i class="fab fa-twitter fa-stack-1x"></i>
                        </a>
                    </span>
                    <span class="fa-stack">
                        <a href="#">
                            <i class="fas fa-circle fa-stack-2x"></i>
                            <i class="fab fa-pinterest-p fa-stack-1x"></i>
                        </a>
                    </span>
                    <span class="fa-stack">
                        <a href="#">
                            <i class="fas fa-circle fa-stack-2x"></i>
                            <i class="fab fa-instagram fa-stack-1x"></i>
                        </a>
                    </span>

                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-2 col-6">
                <div class="footer-col">
                    <h6>Links</h6>
                    <ul class="list-unstyled li-space-lg p-small">
                        <li><a class="page-scroll" href="#header">Home</a></li>
                        <li><a class="page-scroll" href="#intro">About Us</a></li>
                        <li><a class="page-scroll" href="#features">Features</a></li>
                        <li><a class="page-scroll" href="#services">Services</a></li>
                        <li><a class="page-scroll" href="#contact">Contact</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-4 col-6">
                <div class="footer-col">
                    <h6>Services</h6>
                    <ul class="list-unstyled li-space-lg p-small">
                        <li><a class="page-scroll" href="#services">Missing Person</a></li>
                        <li><a class="page-scroll" href="#services">Bank Fraud</a></li>
                        <li><a class="page-scroll" href="#services">Property Dispute</a></li>
                        <li><a class="page-scroll" href="#services">Divorce Case</a></li>
                        <li><a class="page-scroll" href="#services">Shadowing</a></li>
                        
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-5 col-12">
                <div class="footer-col">
                    <h6>Services</h6>
                    <ul class="list-unstyled li-space-lg p-small">
                        <li><a class="page-scroll" href="#services">Post & Pre Marital</a></li>
                        <li><a class="page-scroll" href="#services">Background Verification</a></li>
                        <li><a class="page-scroll" href="#services">Extra Marital Affairs</a></li>
                        <li><a class="page-scroll" href="#services">Internationl Investigation</a></li>
                        <li><a class="page-scroll" href="#services">Kidnapping Investigation</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end of footer -->



<!-- Copyright -->
<div class="copyright">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <p>Copyright &copy; 2021 | <a href="#">Sejal Detactive Agency</a></p>
            </div>
        </div>
    </div>
</div>
<!-- end of copyright -->



<!-- Scripts -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/swiper.min.js"></script>
<script src="js/scripts.js"></script>
<script src="js/jquery.easing.min.js"></script>

</body>

</html>