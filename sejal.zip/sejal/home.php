<!-- Header -->
<header id="header" class="header">
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <div class="text-container">
                    <h1 class="h1-large">Sejal Detective Agency</h1>
                    <p class="p-large">Sejal Detective Agency is the most promising and well-reputed company among all the detective agencies in India. We have departments nationally and internationally with the best investigating support.</p>
                    <a class="btn-solid-lg" href="#contact">Contact Us</a>
                    <a class="btn-outline-lg page-scroll" href="#contact">Hire Us</a>
                </div>

            </div>

            <div class="col-lg-7">
                <div class="image-container">
                    <img class="img-fluid" src="images/dimg.png" alt="alternative">
                </div>
            </div>
        </div>
    </div>
</header>
<!-- end of header -->


<!-- Introduction -->
<div id="intro" class="sejal-1 text-center pt-5">
    <div class="container">
        <div class="row">


            <div class="col-lg-8 offset-lg-2">
                <div class="text-container">
                    <h2>Sejal Detective Agency</h2>
                    <p>Sejal Detective Agency is the most promising and well-reputed company among all the detective agencies in India. We have departments nationally and internationally with the best investigating support. We provide the maximum of our assistance to each corner of the country. Not only that, but we deal with a lot of cases and gained almost 100% customer satisfaction over the period of time. We also provide both personal and corporate Investigation services to the customers. Our objective is not only to serve the customers but also to work in proper behavior which includes a proper reports, solid proofs, and evidence, using the latest technology, and keeping everything confidential..</p>

                </div>

            </div>

        </div>

    </div>

</div>

<!-- end of introduction -->



<!-- services -->
<div class="slider-2 pt-5 pb-4" id="services">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="h2-heading">Our Services</h2>
                <p class="p-heading">Sejal Detective Agency is the most promising and well-reputed company among all the detective agencies in India. </p>
            </div>

        </div>

        <div class="row">
            <div class="col-lg-12">

                <div class="slider-container">
                    <div class="swiper-container card-slider">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="details">
                                            <img class="testimonial-image" src="images/icons/1.png" alt="alternative">
                                            <div class="text">
                                                <div class="testimonial-author"> Divorce Case</div>

                                            </div>

                                        </div>
                                        <p class="testimonial-text">In many divorce cases investigation, extramarital affair plays a very important role, Marriage is an institution where two people, carrying different individualizes, understand the matter and provide shreds of evidence of an extramarital affair. Most of the time, Courts are not able to conclude divorce cases, as both the parties make claims and are not able to substantiate their claims. We provide photographic, video graphics, and documentary proofs. </p>

                                    </div>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="details">
                                            <img class="testimonial-image" src="images/icons/2.png" alt="alternative">
                                            <div class="text">
                                                <div class="testimonial-author">Missing Person</div>

                                            </div>

                                        </div>
                                        <p class="testimonial-text">Either you want to find a person who cheated you or you want to find any missing person investigation Sejal detective agency can help you in this situation. If you are searching for” missing person service” then you are at the right place. We investigate all the details of the missing person and try to figure out the location of the missing person. We also find people who have scammed you and are pretending to be missing.</p>

                                    </div>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="details">
                                            <img class="testimonial-image" src="images/icons/3.png" alt="alternative">
                                            <div class="text">
                                                <div class="testimonial-author">Bank Fraud</div>

                                            </div>

                                        </div>
                                        <p class="testimonial-text">Bank fraud is a white-collar crime type, this involves perpetrators creating fraudulent financial transactions for personal gain. We work for the same and delivers the best services all over India and out of Indian also, you must appoint Sejal DETECTIVE AGENCY, we will help you in arranging proofs for your Verification related to tangible and intangible assets are very important for banks and Finance Companies. We are here to help you out.</p>

                                    </div>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="details">
                                            <img class="testimonial-image" src="images/icons/4.png" alt="alternative">
                                            <div class="text">
                                                <div class="testimonial-author">Post & Pre Marital</div>

                                            </div>

                                        </div>
                                        <p class="testimonial-text">We offer you the best and effective pre/post martial investigation services with confidentiality during the process. We are specialized in this field and provides information on - his/her Character, social reputation, etc. Like Pre-Marital investigations, Post-Marital Investigation is also equally important for a smooth married life. We collect information on - his/ her extra-marital relationship, Spouse fidelity, pre-marriage affair, parental intervention in their married life.</p>

                                    </div>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="details">
                                            <img class="testimonial-image" src="images/icons/5.png" alt="alternative">
                                            <div class="text">
                                                <div class="testimonial-author">Extra Marital Affairs</div>

                                            </div>

                                        </div>
                                        <p class="testimonial-text">We Sejal detective agency understand this situation and put our 100% to resolve extramarital affairs with our best extramarital affair investigation team. We have a large team of detectives who are experienced in resolving such cases, as they are doing the same for many years. With the support of our highly skilled detective team we resolve 1000+ such cases of extra marital affairs. Contact us: +91-998-242-4661 for the best extramarital affair investigation services.</p>

                                    </div>
                                </div>
                            </div>


                            <div class="swiper-slide">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="details">
                                            <img class="testimonial-image" src="images/icons/6.png" alt="alternative">
                                            <div class="text">
                                                <div class="testimonial-author">Property Dispute</div>

                                            </div>

                                        </div>
                                        <p class="testimonial-text">We Offer property dispute Investigation Services. Property dispute is so harmful to any person or a business if it is not resolved on time they might be put in danger and also stop the growth of the business. Our highly ranked detective agency understands this damage and also has an expert team to resolve this dispute. We can provide information, and evidence through in-depth investigation to help and resolve the disputes.</p>

                                    </div>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="details">
                                            <img class="testimonial-image" src="images/icons/7.png" alt="alternative">
                                            <div class="text">
                                                <div class="testimonial-author">Background Check</div>

                                            </div>

                                        </div>
                                        <p class="testimonial-text">Sejal detective agency works on background verification for several companies, businesses, personal & professional records. We also do employment verification of background which includes locations, property, and copyright verification. We decide further strategies which can be legal interdict order. Trusts the chance and hazards can be prevented with sufficient verifications. We do our work by following all the laws and ethics.</p>

                                    </div>
                                </div>
                            </div>

                            

                            <div class="swiper-slide">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="details">
                                            <img class="testimonial-image" src="images/icons/8.png" alt="alternative">
                                            <div class="text">
                                                <div class="testimonial-author">Kidnapping </div>

                                            </div>

                                        </div>
                                        <p class="testimonial-text">Kidnapping can have long-term, even lifelong, consequences for victims and businesses. A demand is made to the family to recover the debt, with the threat of killing them if it is not paid. You can report any instances of kidnapping directly to the Sejal detective agency. We with our experts help you with the best outcome all over in India and out of Indian. You are just one call away, make us a call on +91-998-242-4661 .</p>

                                    </div>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="details">
                                            <img class="testimonial-image" src="images/icons/10.png" alt="alternative">
                                            <div class="text">
                                                <div class="testimonial-author">Shadowing</div>

                                            </div>

                                        </div>
                                        <p class="testimonial-text">Shadowing is a form of surveillance to collect proof as photos, audio, or video clips while monitoring the activities of a subject without their knowledge. Shadowing may be carried out for a few hours or even for days together, it depends on the requirement of the case. This will be done by keeping the secrecy of the case and safeguarding our client's interest. All evidence required for the case will be gathered with the help of our team to help you in this case.</p>

                                    </div>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="details">
                                            <img class="testimonial-image" src="images/icons/9.png" alt="alternative">
                                            <div class="text">
                                                <div class="testimonial-author">Internationl Investigation</div>

                                            </div>

                                        </div>
                                        <p class="testimonial-text">Our team Sejal Detective Services entitle national and international services also if you have an earnest wish to know about the truth related to your spouse, friend, or anyone then our services are also obtainable internationally. They believe in our team and the team’s hard work. We resolve cases and perform various investigations internationally. We also have our highly experienced team for an international investigation.</p>


                                    </div>
                                </div>
                            </div>


                        </div>



                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>


                    </div>

                </div>


            </div>

        </div>

    </div>

</div>

<!-- end of services -->

<div class="ex-sejal-cards-1 pt-5 pb-3">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">


                <div class="card">
                    <ul class="list-unstyled">
                        <li class="media">
                            <span class="fa-stack">
                                <span class="fas fa-circle fa-stack-2x"></span>
                                <span class="fa-stack-1x">1</span>
                            </span>
                            <div class="media-body">
                                <h5>Consultation</h5>
                                <p>Features include an eye catching morphtext in the header, details lightbox for more details information</p>
                            </div>
                        </li>
                    </ul>
                </div>

                <div class="card">
                    <ul class="list-unstyled">
                        <li class="media">
                            <span class="fa-stack">
                                <span class="fas fa-circle fa-stack-2x"></span>
                                <span class="fa-stack-1x">2</span>
                            </span>
                            <div class="media-body">
                                <h5>Strategize</h5>
                                <p>Statistics numbers for important values, card slider for testimonials, image slider for customer logos</p>
                            </div>
                        </li>
                    </ul>
                </div>

                <div class="card">
                    <ul class="list-unstyled">
                        <li class="media">
                            <span class="fa-stack">
                                <span class="fas fa-circle fa-stack-2x"></span>
                                <span class="fa-stack-1x">3</span>
                            </span>
                            <div class="media-body">
                                <h5>Take Action</h5>
                                <p>Some useful extra pages are bundled with the template lik article details, terms conditions and privacy policy</p>
                            </div>
                        </li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
</div>



<!-- Features -->
<div id="features" class="sejal-cards-1 pt-5 pb-3">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="h2-heading">Check out all the Features</h2>
                <p class="p-heading">Sejal Detective Agency is the most promising and well-reputed company among all the detective agencies in India. </p>
            </div>

        </div>

        <div class="row">
            <div class="col-lg-12">


                <div class="card">
                    <div class="card-icon-wrapper">
                        <div class="card-icon">
                            <span class="fas fa-headphones-alt green"></span>
                        </div>
                    </div>
                    <div class="card-body">
                        <h4 class="card-title">Best Detactive Agency</h4>
                        <p>Best service in India and our success rate for investigation matters and also speaks for the company's reputation itself. 100% customer satisfaction.

</p>

                    </div>
                </div>

                <div class="card">
                    <div class="card-icon-wrapper">
                        <div class="card-icon">
                            <span class="far fa-clipboard blue"></span>
                        </div>
                    </div>
                    <div class="card-body">
                        <h4 class="card-title">Experinced Management</h4>
                        <p>And of course, customer experience also depends on the overhead quality of services provided and customer satisfaction</p>

                    </div>
                </div>



                <div class="card">
                    <div class="card-icon-wrapper">
                        <div class="card-icon">
                            <span class="far fa-comments purple"></span>
                        </div>
                    </div>
                    <div class="card-body">
                        <h4 class="card-title">Privacy Assured</h4>
                        <p>Any information obtained in prince detactive agency that could identify the subject will remain confidential and will not be disclosed.</p>

                    </div>
                </div>



            </div>

        </div>

    </div>

</div>

<!-- end of features -->

<!-- Details 1 -->
<div id="details" class="sejal-basic-2 pt-5 pb-4">
    <div class="container">
        <div class="row">
            <div class="col-lg-9">
                <div class="intro">
                    <h2>Best Detective Agecny</h2>
                    <p>Sejal Detective Agency is the most promising and well-reputed company among all the detective agencies in India.</p>
                </div>

            </div>

        </div>

        <div class="row">
            <div class="col-lg-7">
                <div class="image-container">
                    <img class="img-fluid" src="images/varitey.png" alt="alternative">
                </div>

            </div>

            <div class="col-lg-5">
                <div class="text-container">

                    <h3>Personal Investigations</h3>
                    <h3>Corporate Investigations</h3>
                    <h3>Specialized Services</h3>
                    <h3>Unique Services</h3>

                </div>

            </div>

        </div>

    </div>

</div>

<!-- end of details 1 -->

<section class="sejal-counter bg-light py-5" id="section-counter">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-6 justify-content-center">
                <div class="block-18 d-flex my-3">
                    <div class="icon d-flex justify-content-center align-items-center">
                        <span class="flaticon-suitcase"><i class="fas fa-file-invoice"></i></span>
                    </div>
                    <div class="text">
                        <strong class="number" data-number="6000">5000</strong>
                        <span>Project Complete</span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-6 justify-content-center">
                <div class="block-18 d-flex my-3">
                    <div class="icon d-flex justify-content-center align-items-center">
                        <span class="flaticon-loyalty"><i class="far fa-user-circle"></i></span>
                    </div>
                    <div class="text">
                        <strong class="number" data-number="6000">5000</strong>
                        <span>Happy Clients</span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-6 justify-content-center">
                <div class="block-18 d-flex my-3">
                    <div class="icon d-flex justify-content-center align-items-center">
                        <span class="flaticon-coffee"><i class="far fa-user"></i></span>
                    </div>
                    <div class="text">
                        <strong class="number" data-number="250">200</strong>
                        <span>Team Members</span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-6 justify-content-center">
                <div class="block-18 d-flex my-3">
                    <div class="icon d-flex justify-content-center align-items-center">
                        <span class="flaticon-calendar"><i class="fas fa-cogs"></i></span>
                    </div>
                    <div class="text">
                        <strong class="number" data-number="15">15</strong>
                        <span>Years experienced</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- conatct -->
<div class="form-1 pt-4 pb-3" id="contact">
    <div class="container">
        <div class="row text-center">
            <div class="col-lg-12">
                <h2 class="h2-heading">Contact Us</h2>
                <p class="p-heading">Be part of the story and follow us on Twitter via and subscribe to the newsletter for news and updates about our workshops</p>
            </div>

        </div>

        <div class="row">
            <div class="col-lg-8">

                <form method="POST">
                    <div class="form-group">

                        <input type="text" class="form-control-input" id="name" required>
                        <label class="label-control" for="name">Email Name</label>
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control-input" id="email" required>
                        <label class="label-control" for="email">Email address</label>

                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control-input" id="Number" required>
                        <label class="label-control" for="Number">Your Number</label>

                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control-input" id="reason" required>
                        <label class="label-control" for="reason">Reason</label>

                    </div>
                    <div class="form-group">
                        <textarea name="message" id="message" class="form-control-textarea" cols="40" rows="3"></textarea>
                        <label class="label-control" for="message">Messages</label>

                    </div>
                    <div class="">
                        <button type="submit" class="form-control-submit-button">Subscribe</button>
                    </div>

                </form>


            </div>

            <div class="col-md-4">
                <img src="images/contactimg.jpg" alt="" width="100%" class="d-none d-lg-block">
            </div>

        </div>

    </div>

</div>

<!-- conatct -->