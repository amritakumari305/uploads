<div class="icon-bar">
 <a href="https://api.whatsapp.com/send?phone=+919982424661" class="facebook" target="_blank"><i class="fab fa-whatsapp"></i></a>
</div>
<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-6">
                    <h3 class="h7">Site Link</h3>
                    <address class="footer-info">
                        <div class="f-unit">
                          <div class="f-unit-left"><span class="icon-xs"><i class="fas fa-phone-alt" aria-hidden="true"></i></span></div>
                          <div class="f-unit-body"><a class="link-white" href="tel:9982424661">+91-998-242-4661</a></div>
                        </div>
                        <div class="f-unit">
                          <div class="f-unit-left"><span class="icon-xs"><i class="far fa-envelope" aria-hidden="true"></i></span></div>
                          <div class="f-unit-body"><a class="link-white" href="mailto:info@princedetactive.com">info@princedetactive.com</a></div>
                        </div>
                        <div class="f-unit">
                          <div class="f-unit-left"><span class="icon-xs"><i class="fas fa-map-marker-alt" aria-hidden="true"></i></span></div>
                          <div class="f-unit-body"><a class="link-white d-inline" href="#">3rd floor,84 Arvind Building, Tilak Rd, Gatkopar East mumbai 400077, India</a></div>
                        </div>
                      </address>
                    <div class="social-sec">
                        <ul class="list-inline w-100">

                            <li class="d-inline-block social px-1">
                                <a href="http://twitter.com"><i class="fab fa-twitter" aria-hidden="true"></i></a>
                            </li>
                            <li class="d-inline-block social px-1">
                                <a href="http://facebook.com"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
                            </li>
                            <li class="d-inline-block social px-1">
                                <a href="http://youtube.com"><i class="fab fa-youtube" aria-hidden="true"></i></a>
                            </li>
                            <li class="d-inline-block social px-1">
                                <a href="http://instagram.com"><i class="fab fa-instagram" aria-hidden="true"></i></a>
                            </li>
                            <li class="d-inline-block social px-1">
                                <a href="http://instagram.com"><i class="fab fa-google" aria-hidden="true"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-2 col-sm-6">
                    <h3 class="h7">Site Link</h3>
                    <ul class="footer-list-marked">
                        <li><a href="index.php"><i class="fas fa-angle-right"></i> Home</a></li>
                        <li><a href="about.php"><i class="fas fa-angle-right"></i>About US</a></li>
                        <li><a href="contact.php"><i class="fas fa-angle-right"></i> Contact Us</a></li>
                        <li><a href="services.php"><i class="fas fa-angle-right"></i> Services</a></li>

                    </ul>
                </div>
                <div class="col-md-6 col-sm-12">
                    <h3 class="h7">Our Services</h3>
                    <div class="row">
                        <div class="col-12 col-sm-6">
                            <ul class="footer-list-marked">
                                <li><a href="services.php"><i class="fas fa-angle-right"></i> Internationl Investigation</a></li>
                                <li><a href="services.php"><i class="fas fa-angle-right"></i> Extra Marital Affairs</a></li>
                                <li><a href="services.php"><i class="fas fa-angle-right"></i> Property Dispute</a></li>
                                <li><a href="services.php"><i class="fas fa-angle-right"></i> Background Verification</a></li>
                                <li><a href="services.php"><i class="fas fa-angle-right"></i> Kidnapping Investigation</a></li>
                            </ul>
                        </div>
                        <div class="col-12 col-sm-6">
                            <ul class="footer-list-marked">
                                <li><a href="services.php"><i class="fas fa-angle-right"></i> Missing Person</a></li>
                                <li><a href="services.php"><i class="fas fa-angle-right"></i> Bank Fraud</a></li>
                                <li><a href="services.php"><i class="fas fa-angle-right"></i> Post & Pre Marital</a></li>
                                <li><a href="services.php"><i class="fas fa-angle-right"></i> Divorce Case</a></li>
                                <li><a href="services.php"><i class="fas fa-angle-right"></i> Shadowing</a></li>
                            </ul>
                        </div>
                    </div>
                </div>


            </div>
        </div>
        <div class="copyright text-center">
            <div class="container">
                <div class="col-md-12">
                    <div>
                        <p>Copyright &copy; 2020 | Design &amp; Developed by :
                            <a href="https://coralitsolution.com/" target="_blank"><img src="images/coral-logo.png" alt="" width="130"></a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>