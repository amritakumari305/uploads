<?php
include("header.php");
include("menu.php");
?>
<section class="bredcrumbe-section text-center py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="breadcrumbs my-3">
                    <h3 class="text-center">Services</h3>
                </div>
                <div class="breadcrumb-subtitle">
                    <ul class="list-inline">
                        <li class="d-inline"><a href="index.php" class="active">Home</a></li>
                        <li class="d-inline"><a href="">/</a></li>
                        <li class="d-inline"><a href="services.php">Services</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>



<section class="services-page py-4">
    <div class="container">
    <div class="row">
            <div class="col-md-6">
                <div class="prince_service style-7">
                    <!-- <div class="icon-wrapper">
                        <span class="flaticon-documents services-icon-box">
                            <img src="images/icon/1.png" alt="">
                            <span>1</span>
                        </span>
                    </div> -->
                    <div class="prince_service-body">
                        <h5>
                            <a href="services.php">Internationl Investigation</a>
                        </h5>
                        <p>Our team Prince  Detective Services entitle national and international services also if you have an earnest wish to know about the truth related to your spouse, friend, or anyone then our services are also obtainable internationally. They believe in our team and the team’s hard work. We resolve cases and perform various investigations internationally.
We also have our highly experienced team internationally for an international investigation. </p>
                    </div>
                    <div class="prince_service-thumb">
                        <img src="images/services/s1.jpg" alt="img">
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="prince_service style-7">
                    <!-- <div class="icon-wrapper">
                        <span class="flaticon-documents services-icon-box">
                            <img src="images/icon/2.png" alt="">
                            <span>2</span>
                        </span>
                    </div> -->
                    <div class="prince_service-body">
                        <h5>
                            <a href="services.php">Missing Person</a>
                        </h5>
                        <p>Either you want to find a person who cheated you or you want to find any missing person investigation prince detective agency can help you in this situation. If you are searching for” missing person service” then you are at the right place.  We investigate all the details of the missing person and try to figure out the location of the missing person. We also find people who have scammed you and are pretending to be missing.</p>
                    </div>
                    <div class="prince_service-thumb">
                        <img src="images/services/s2.jpg" alt="img">
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="prince_service style-7">
                    <!-- <div class="icon-wrapper">
                        <span class="flaticon-documents services-icon-box">
                            <img src="images/icon/3.png" alt="">
                            <span>3</span>
                        </span>
                    </div> -->
                    <div class="prince_service-body">
                        <h5>
                            <a href="services.php">Bank Fraud</a>
                        </h5>
                        <p>Bank fraud is a white-collar crime type, this involves perpetrators creating fraudulent financial transactions for personal gain. We work for the same and delivers the best services all over India and out of Indian also,  you must appoint PRINCE DETECTIVE AGENCY, we will help you in arranging proofs for your Verification related to tangible and intangible assets are very important for banks and Finance Companies. We are here to help you out.</p>
                    </div>
                    <div class="prince_service-thumb">
                        <img src="images/services/s3.jpg" alt="img">
                    </div>
                </div>
            </div>


            <div class="col-md-6">
                <div class="prince_service style-7">
                    <!-- <div class="icon-wrapper">
                        <span class="flaticon-documents services-icon-box">
                            <img src="images/icon/4.png" alt="">
                            <span>4</span>
                        </span>
                    </div> -->
                    <div class="prince_service-body">
                        <h5>
                            <a href="services.php">Extra Marital Affairs</a>
                        </h5>
                        <p>We prince detective  agency understand this situation and put our 100% to resolve extramarital affairs with our best extramarital affair investigation team. We have a large team of detectives who are experienced in resolving such cases, as they are  doing the same for many years. With the support of our highly skilled detective team we resolve 1000+ such cases of extra marital affairs. Contact us: 
+91-998-242-4661 for the best extramarital affair investigation services.</p>
                    </div>
                    <div class="prince_service-thumb">
                        <img src="images/services/s4.jpg" alt="img">
                    </div>
                </div>
            </div>


            <div class="col-md-6">
                <div class="prince_service style-7">
                    <!-- <div class="icon-wrapper">
                        <span class="flaticon-documents services-icon-box">
                            <img src="images/icon/5.png" alt="">
                            <span>5</span>
                        </span>
                    </div> -->
                    <div class="prince_service-body">
                        <h5>
                            <a href="services.php">Property Dispute</a>
                        </h5>
                        <p>We Offer property dispute Investigation Services. Property dispute is so harmful to any person or a business if it is not resolved on time they might be put in danger and also stop the growth of the business. Our highly ranked detective agency understands this damage and also has an expert team to resolve this dispute. We can provide information, and evidence through in-depth investigation to help and resolve the disputes.</p>
                    </div>
                    <div class="prince_service-thumb">
                        <img src="images/services/s5.jpg" alt="img">
                    </div>
                </div>
            </div>


            <div class="col-md-6">
                <div class="prince_service style-7">
                    <!-- <div class="icon-wrapper">
                        <span class="flaticon-documents services-icon-box">
                            <img src="images/icon/6.png" alt="">
                            <span>6</span>
                        </span>
                    </div> -->
                    <div class="prince_service-body">
                        <h5>
                            <a href="services.php">Background Verification</a>
                        </h5>
                        <p>Prince detective agency works on background verification for several companies, businesses, personal & professional records. We also do employment verification of background which includes locations, property, and copyright verification. We decide further strategies which can be legal interdict order. Trusts the chance and hazards can be prevented with sufficient verifications.
We do our work by following all the laws and ethics disclosed by the company.</p>
                    </div>
                    <div class="prince_service-thumb">
                        <img src="images/services/s6.jpg" alt="img">
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="prince_service style-7">
                    <!-- <div class="icon-wrapper">
                        <span class="flaticon-documents services-icon-box">
                            <img src="images/icon/6.png" alt="">
                            <span>6</span>
                        </span>
                    </div> -->
                    <div class="prince_service-body">
                        <h5>
                            <a href="services.php">Post & Pre Marital</a>
                        </h5>
                        <p>We offer you the best and effective pre/post martial investigation services with confidentiality during the process.  We are specialized in this field and provides information on - his/her Character, social reputation, etc. Like Pre-Marital investigations, Post-Marital Investigation is also equally important for a smooth married life. We collect information on - his/ her extra-marital relationship, Spouse fidelity, pre-marriage affair, parental intervention in their married life.</p>
                    </div>
                    <div class="prince_service-thumb">
                        <img src="images/services/s7.jpg" alt="img">
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="prince_service style-7">
                    <!-- <div class="icon-wrapper">
                        <span class="flaticon-documents services-icon-box">
                            <img src="images/icon/6.png" alt="">
                            <span>6</span>
                        </span>
                    </div> -->
                    <div class="prince_service-body">
                        <h5>
                            <a href="services.php">Divorce Case</a>
                        </h5>
                        <p>In many divorce cases investigation, extramarital affair plays a very important role, Marriage is an institution where two people, carrying different individualizes, understand the matter and provide shreds of evidence of an extramarital affair.  Most of the time, Courts are not able to conclude divorce cases, as both the parties make claims and are not able to substantiate their claims. We provide photographic, video graphics, and documentary proofs to the court.</p>
                    </div>
                    <div class="prince_service-thumb">
                        <img src="images/services/s8.jpg" alt="img">
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="prince_service style-7">
                    <!-- <div class="icon-wrapper">
                        <span class="flaticon-documents services-icon-box">
                            <img src="images/icon/6.png" alt="">
                            <span>6</span>
                        </span>
                    </div> -->
                    <div class="prince_service-body">
                        <h5>
                            <a href="services.php">Shadowing</a>
                        </h5>
                        <p>Shadowing is a form of surveillance to collect proof as photos, audio, or video clips while monitoring the activities of a subject without their knowledge. Shadowing may be carried out for a few hours or even for days together, it depends on the requirement of the case. This will be done by keeping the secrecy of the case and safeguarding our client's interest. All evidence required for the case will be gathered with the help of our team to help you in this case.</p>
                    </div>
                    <div class="prince_service-thumb">
                        <img src="images/services/s9.jpg" alt="img">
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="prince_service style-7">
                    <!-- <div class="icon-wrapper">
                        <span class="flaticon-documents services-icon-box">
                            <img src="images/icon/6.png" alt="">
                            <span>6</span>
                        </span>
                    </div> -->
                    <div class="prince_service-body">
                        <h5>
                            <a href="services.php">Kidnapping Investigation</a>
                        </h5>
                        <p>Kidnapping can have long-term, even lifelong, consequences for victims and businesses.  A demand is made to the family to recover the debt, with the threat of killing them if it is not paid. You can report any instances of kidnapping directly to the prince detective agency. We with our experts help you with the best outcome all over in India and out of Indian. You are just one call away, make us a call on 
+91-998-242-4661 .</p>
                    </div>
                    <div class="prince_service-thumb">
                        <img src="images/services/s10.jpeg" alt="img">
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>


<?php include("footer.php"); ?>