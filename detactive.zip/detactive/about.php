<?php
include("header.php");
include("menu.php");
?>
<section class="bredcrumbe-section text-center py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="breadcrumbs my-3">
                    <h3 class="text-center">About Us</h3>
                </div>
                <div class="breadcrumb-subtitle">
                    <ul class="list-inline">
                        <li class="d-inline"><a href="index.php" class="active">Home</a></li>
                        <li class="d-inline"><a href="">/</a></li>
                        <li class="d-inline"><a href="about.php">About Us</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="about-sec py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <div class="about-img">
                    <img src="images/about-img.png" alt="about-img" width="100%">
                </div>
            </div>
            <div class="col-md-7">
                <div class="about-sec mt-5">
                    <h5 class="mb-4">About Us</h5>
                    <h2 class="mb-4">Introducing the Private Investigation Agency</h2>
                    <p class="mb-4">Prince Detective Agency is the most promising and well-reputed company among all the detective agencies in India. We have departments nationally and internationally with the best investigating support. We provide the maximum of our assistance to each corner of the country. Not only that, but we deal with a lot of cases and gained almost 100% customer satisfaction over the period of time. We also provide both personal and corporate Investigation services to the customers. Our objective is not only to serve the customers but also to work in proper behavior which includes a proper reports, solid proofs, and evidence, using the latest technology, and keeping everything confidential. All together forms a very adequate order of working and also helps in providing exact information to our customers.</p>
                                    </div>
            </div>
            <div class="col-md-12">
            <p>Our agency is fast and also don’t consume much time in one case, we clear up cases fast so that our customers can have better decision power in their hand. Our team members are not lethargic; they work in a boost mode to provide the leading backing to our customers. Our intent is to clarify the problems of our customers first and fast, as we connect with our clients and after knowing the problem which may be very complicated but if we delay the work then can land up in terrible situation.</p>
                    <p>We also untangle all the marital and non-marital cases that comes under personal investigation. Iron out all your problems with Prince Detective Agency anytime and ready to solve your doubt and get out of the situation.</p>

            </div>
        </div>
    </div>
</section>
<section class="counter-sec pt-4 pb-3">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-4">

                <div class="countings">
                    <i class="far fa-file-alt"></i>
                    <h5><a href="#">Cases Handled</a></h5>

                    <div class="divider"></div>

                    <p>100 +</p>
                </div>

            </div>
            <div class="col-md-4">
                <div class="countings">
                    <i class="far fa-user"></i>
                    <h5><a href="#">Satisfied Client</a></h5>

                    <div class="divider"></div>

                    <p>100 +</p>

                </div>

            </div>
            <div class="col-md-4">
                <div class="countings">
                    <i class="far fa-heart"></i>
                    <h5><a href="#">Year's Experinced</a></h5>

                    <div class="divider"></div>

                    <p>10 +</p>

                </div>
            </div>
        </div>
    </div>
</section>

<section class="how-it-works py-5">
    <div class="container">
        <div class="row mb-5">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h2 class="text-white">How It <span class="primary-color"> Works </span></h2>

                </div>
            </div>

        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="work-box text-center">
                    <div class="work-icon">
                        <span>01</span>
                    </div>
                    <h3>Consultation</h3>
                </div>
            </div>
            <div class="col-md-4">
                <div class="work-box text-center">
                    <div class="work-icon">
                        <span>02</span>
                    </div>
                    <h3>Strategize</h3>
                </div>
            </div>
            <div class="col-md-4">
                <div class="work-box text-center">
                    <div class="work-icon">
                        <span>03</span>
                    </div>
                    <h3>Take Action</h3>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="features-sec pt-2 pb-3">
    <div class="container">
        <div class="row">
            <div class="col-md-4 height-fill">
                <article class="icon-box">
                    <div class="box-top">
                        <div class="box-icon"><i class="fas fa-search icon"></i></div>
                        <div class="box-header">
                            <h5><a href="#">Best Detactive Agency</a></h5>
                        </div>
                    </div>
                    <div class="divider"></div>
                    <div class="box-body">
                        <p>Best service in India and our success rate for investigation matters and also speaks for the company's reputation itself.</p>
                    </div>
                </article>
            </div>
            <div class="col-md-4 height-fill">
                <article class="icon-box">
                    <div class="box-top">
                        <div class="box-icon"><i class="fab fa-redhat icon"></i></div>
                        <div class="box-header">
                            <h5><a href="#">Experinced Management</a></h5>
                        </div>
                    </div>
                    <div class="divider"></div>
                    <div class="box-body">
                        <p>And of course, customer experience also depends on the overhead quality of services provided  and customer satisfaction</p>
                    </div>
                </article>
            </div>
            <div class="col-md-4 height-fill">
                <article class="icon-box">
                    <div class="box-top">
                        <div class="box-icon"><i class="fas fa-mask icon"></i></div>
                        <div class="box-header">
                            <h5><a href="#">Privacy and Confidentiality Assured</a></h5>
                        </div>
                    </div>
                    <div class="divider"></div>
                    <div class="box-body">
                        <p>Any information obtained in prince detactive agency that could identify the subject will remain confidential and will not be disclosed.</p>
                    </div>
                </article>
            </div>
        </div>
    </div>
</section>
<?php include("footer.php"); ?>