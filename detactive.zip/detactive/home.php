<div class="main-slider">
    <div id="demo" class="carousel slide" data-ride="carousel">
        <!-- The slideshow -->
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="images/slider/slider1.jpg" alt="slider1" width="100%">
            </div>
            <div class="carousel-item">
                <img src="images/slider/slider1.jpg" alt="slider2" width="100%">
            </div>
            <div class="carousel-item">
                <img src="images/slider/slider1.jpg" alt="slider3" width="100%">
            </div>
        </div>

        <!-- Left and right controls -->
        <a class="carousel-control-prev" href="#demo" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </a>
        <a class="carousel-control-next" href="#demo" data-slide="next">
            <span class="carousel-control-next-icon"></span>
        </a>
    </div>
</div>


<section class="features-sec pt-2 pb-3">
    <div class="container">
        <div class="row">
            <div class="col-md-4 height-fill">
                <article class="icon-box">
                    <div class="box-top">
                        <div class="box-icon"><i class="fas fa-search icon"></i></div>
                        <div class="box-header">
                            <h5><a href="#">Best Detactive Agency</a></h5>
                        </div>
                    </div>
                    <div class="divider"></div>
                    <div class="box-body">
                   
                        <p>Best service in India and our success rate for investigation matters and also speaks for the company's reputation itself.</p>
                    </div>
                </article>
            </div>
            <div class="col-md-4 height-fill">
                <article class="icon-box">
                    <div class="box-top">
                        <div class="box-icon"><i class="fab fa-redhat icon"></i></div>
                        <div class="box-header">
                            <h5><a href="#">Experinced Management</a></h5>
                        </div>
                    </div>
                    <div class="divider"></div>
                    <div class="box-body">
                        <p>And of course, customer experience also depends on the overhead quality of services provided  and customer satisfaction</p>
                    </div>
                </article>
            </div>
            <div class="col-md-4 height-fill">
                <article class="icon-box">
                    <div class="box-top">
                        <div class="box-icon"><i class="fas fa-mask icon"></i></div>
                        <div class="box-header">
                            <h5><a href="#">Privacy and Confidentiality Assured</a></h5>
                        </div>
                    </div>
                    <div class="divider"></div>
                    <div class="box-body">
                        <p> Any information obtained in prince detactive agency that could identify the subject will remain confidential and will not be disclosed.</p>
                    </div>
                </article>
            </div>
        </div>
    </div>
</section>

<section class="about-sec py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <div class="about-img">
                    <img src="images/about-img.png" alt="about-img" width="100%">
                </div>
            </div>
            <div class="col-md-7">
                <div class="about-sec mt-3">
                    <h5 class="mb-4">About Us</h5>
                    <h2 class="mb-4">Introducing the Private Investigation Agency</h2>
                    <p class="mb-4">Prince Detective Agency is the most promising and well-reputed company among all the detective agencies in India. We have departments nationally and internationally with the best investigating support. We provide the maximum of our assistance to each corner of the country. Not only that, but we deal with a lot of cases and gained almost 100% customer satisfaction over the period of time. We also provide both personal and corporate Investigation services to the customers. Our objective is not only to serve the customers but also to work in proper behavior which includes a proper reports, solid proofs, and evidence, using the latest technology, and keeping everything confidential..</p>
                    <div class="button-about pt-4">
                        <a href="about.php">See More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<section class="services py-4">
    <div class="container">
        <div class="row mb-5">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h2>Our <span class="primary-color">Services</span></h2>
                    <p>Offering Private Investigation Services</p>
                </div>
            </div>

        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="prince_service style-7">
                    <div class="icon-wrapper">
                        <span class="flaticon-documents services-icon-box">
                            <img src="images/icon/1.png" alt="">
                            <span>1</span>
                        </span>
                    </div>
                    <div class="prince_service-body">
                        <h5>
                            <a href="services.php">Internationl Investigation</a>
                        </h5>
                        <p>Our team Prince  Detective Services entitle national and international services also if you have an earnest..</p>
                    </div>
                    <div class="prince_service-thumb">
                        <img src="images/services/s1.jpg" alt="img">
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="prince_service style-7">
                    <div class="icon-wrapper">
                        <span class="flaticon-documents services-icon-box">
                            <img src="images/icon/2.png" alt="">
                            <span>2</span>
                        </span>
                    </div>
                    <div class="prince_service-body">
                        <h5>
                            <a href="services.php">Missing Person</a>
                        </h5>
                        <p>If you are searching for” missing person service” then you are at the right place. We investigate all the details..</p>
                    </div>
                    <div class="prince_service-thumb">
                        <img src="images/services/s2.jpg" alt="img">
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="prince_service style-7">
                    <div class="icon-wrapper">
                        <span class="flaticon-documents services-icon-box">
                            <img src="images/icon/3.png" alt="">
                            <span>3</span>
                        </span>
                    </div>
                    <div class="prince_service-body">
                        <h5>
                            <a href="services.php">Bank Fraud</a>
                        </h5>
                        <p>Bank fraud is a white-collar crime type, this involves perpetrators creating fraudulent financial transactions..</p>
                    </div>
                    <div class="prince_service-thumb">
                        <img src="images/services/s3.jpg" alt="img">
                    </div>
                </div>
            </div>


            <div class="col-md-4">
                <div class="prince_service style-7">
                    <div class="icon-wrapper">
                        <span class="flaticon-documents services-icon-box">
                            <img src="images/icon/4.png" alt="">
                            <span>4</span>
                        </span>
                    </div>
                    <div class="prince_service-body">
                        <h5>
                            <a href="services.php">Extra Marital Affairs</a>
                        </h5>
                        <p>We prince detective  agency understand this situation and put our 100% to resolve extramarital affairs..</p>
                    </div>
                    <div class="prince_service-thumb">
                        <img src="images/services/s4.jpg" alt="img">
                    </div>
                </div>
            </div>


            <div class="col-md-4">
                <div class="prince_service style-7">
                    <div class="icon-wrapper">
                        <span class="flaticon-documents services-icon-box">
                            <img src="images/icon/5.png" alt="">
                            <span>5</span>
                        </span>
                    </div>
                    <div class="prince_service-body">
                        <h5>
                            <a href="services.php">Property Dispute</a>
                        </h5>
                        <p>Property dispute is so harmful to any person or a business if it is not resolved on time..</p>
                    </div>
                    <div class="prince_service-thumb">
                        <img src="images/services/s5.jpg" alt="img">
                    </div>
                </div>
            </div>


            <div class="col-md-4">
                <div class="prince_service style-7">
                    <div class="icon-wrapper">
                        <span class="flaticon-documents services-icon-box">
                            <img src="images/icon/6.png" alt="">
                            <span>6</span>
                        </span>
                    </div>
                    <div class="prince_service-body">
                        <h5>
                            <a href="services.php">Background Verification</a>
                        </h5>
                        <p>Prince detective agency works on background verification for personal & professional records.</p>
                    </div>
                    <div class="prince_service-thumb">
                        <img src="images/services/s6.jpg" alt="img">
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="button-menu my-2 text-center">
                    <a href="services.php">See All</a>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="how-it-works py-5">
    <div class="container">
        <div class="row mb-5">
            <div class="col-md-12">
                <div class="section-title text-center">
                    <h2 class="text-white">How It <span class="primary-color"> Works </span></h2>

                </div>
            </div>

        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="work-box text-center">
                    <div class="work-icon">
                        <span>01</span>
                    </div>
                    <h3>Consultation</h3>
                </div>
            </div>
            <div class="col-md-4">
                <div class="work-box text-center">
                    <div class="work-icon">
                        <span>02</span>
                    </div>
                    <h3>Strategize</h3>
                </div>
            </div>
            <div class="col-md-4">
                <div class="work-box text-center">
                    <div class="work-icon">
                        <span>03</span>
                    </div>
                    <h3>Take Action</h3>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="area-sec py-4">
    <div class="container">
        <div class="row">

            <div class="col-md-7">
                <div class="subtitle-sec mt-5">

                    <h2 class="mb-4">Our Practice <span class="primary-color"> Areas </span></h2>
                    <p>Offering Private Investigation Services</p>
                </div>

                <div class="area-list">
                    <ol type="1">
                        <li>Personal Investigations</li>
                        <li>Corporate Investigations</li>
                        <li>Specialized Services</li>
                        <li>Unique Services</li>
                    </ol>
                </div>
            </div>
            <div class="col-md-5">
                <div class="area-img d-none d-md-block text-center">
                    <img src="images/d1.jpg" alt="detactive-img">
                </div>
            </div>
        </div>
    </div>
</section>