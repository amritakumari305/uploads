<body>
    <div class="prince-agency-header">
        <header>
            <!-- pd CODE-->
            <div class="top-header">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-7 col-md-12 col-sm-12">
                            <div class="prince-info">
                                <ul class="list-inline w-100 mt-2 text-lg-left text-center">

                                    <li class="d-inline-block social px-2">
                                        <a href="tel:9982424661"> <i class="fas fa-phone-alt mr-1"></i> +91-998-242-4661</a>
                                    </li>
                                    <li class="d-inline-block social px-2">
                                        <a href=""> | </a>
                                    </li>
                                    <li class="d-inline-block social px-2">
                                        <a href="mailto:info@princedetactive.com"><i class="far fa-envelope mr-1"></i> info@princedetactive.com</a>
                                    </li>

                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-5 col-md-12 col-sm-12">
                            <div class="social-sec">
                                <ul class="list-inline w-100 mt-2 text-lg-right text-center">

                                    <li class="d-inline-block social px-1">
                                        <a href="http://twitter.com"><i class="fab fa-twitter"></i></a>
                                    </li>
                                    <li class="d-inline-block social px-1">
                                        <a href="http://facebook.com"><i class="fab fa-facebook-f"></i></a>
                                    </li>
                                    <li class="d-inline-block social px-1">
                                        <a href="http://youtube.com"><i class="fab fa-youtube"></i></a>
                                    </li>
                                    <li class="d-inline-block social px-1">
                                        <a href="http://instagram.com"><i class="fab fa-instagram"></i></a>
                                    </li>
                                    <li class="d-inline-block social px-1">
                                        <a href="http://instagram.com"><i class="fab fa-google"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bottom-header">
                <div class="container">
                    <!-- SNIPPET CODE: 1.NAVBAR TOGLLE BUTTON-->
                    <nav class="navbar navbar-expand-md navbar-dark sticky-top">

                        <a class="navbar-brand" href="index.php"><img src="images/logo2.png" width="100" alt=""></a>
                        <!-- SNIPPET CODE: 1.NAVBAR TOGLLE BUTTON-->
                        <div class="navbar-toggler-right">
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                        </div>


                        <!-- SNIPPET CODE: 2.NAVBAR MAIN MENU-->

                        <div class="collapse navbar-collapse" id="navbar">

                            <ul class="navbar-nav mx-auto">
                                <li class="nav-item active">
                                    <a class="nav-link nav-link-lt" href="index.php">Home <span class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="about.php">About Us</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="contact.php">Contact Us </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" href="services.php">Services</a>
                                </li>

                            </ul>

                            <div class="button-menu my-2">
                                 <a href="contact.php">Hire Us</a>
                            </div>


                        </div>

                    </nav>
                </div>
            </div>

        </header>
    </div>