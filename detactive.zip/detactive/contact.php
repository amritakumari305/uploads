<?php
include("header.php");
include("menu.php");

if (isset($_POST['submit'])) {

    $fullname = $_POST['fullname'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $reason = $_POST['reason'];
    $message = $_POST['message'];

    $to = "hr@coralitsolution.com";

    $to = "sahibkhan846@gmail.com";


    $subject = 'Enquiry :'. $_POST['reason'];
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";


    mail($to, $subject, $message, $headers);
}


?>
<section class="bredcrumbe-section text-center py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="breadcrumbs my-3">
                    <h3 class="text-center">Contact Us</h3>
                </div>
                <div class="breadcrumb-subtitle">
                    <ul class="list-inline">
                        <li class="d-inline"><a href="index.php" class="active">Home</a></li>
                        <li class="d-inline"><a href="">/</a></li>
                        <li class="d-inline"><a href="contact.php">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="conatct-sec py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="subtitle-sec mb-3">

                    <h2 class="mb-4">Contact<span class="primary-color"> Us </span></h2>
                    <span>Fill the below form to get in touch with us for Personal & Corporate Investigations</span>
                </div>
                <?php
                if (isset($inserted) && !empty($inserted)) {
                ?>
                    <span class="input-group-text bg-success text-white "><?php echo $inserted; ?></span>
                <?php
                }
                ?>
                <span></span>
                <div class="contact-boxs mb-3">
                    <form class="contact-form" action="" method="post">
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <label>Name</label>
                                    <input type="text" name="fullname" placeholder="Enter Name" class="form-control">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Phone no.</label>
                                    <input type="number" name="phone" placeholder="+1" class="form-control">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Email</label>
                                    <input type="email" name="email" placeholder="Enter Email" class="form-control">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label>Reason</label>
                                    <input type="text" name="reason" placeholder="Enter Reason" class="form-control">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label>Message</label>
                                    <textarea name="message" rows="3" placeholder="Leave Your Message" class="form-control"></textarea>
                                </div>
                            </div>

                            <div class="col-12">

                                <div class="button-menu my-2">
                                    <button type="submit" name="submit" class="btn btn-primary">Send Message</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <div class="contact-address">
                    <div class="subtitle-sec mb-3">

                        <h2 class="mb-4">How to Find<span class="primary-color"> Us </span></h2>
                        <span>
                            Get in touch with us for Personal & Corporate Investigations</span>
                    </div>

                    <div class="prince_contact-block">
                        <h5>Address</h5>
                        <p>3rd floor,84 Arvind Building, Tilak Rd, Gatkopar East mumbai 400077, India</p>

                    </div>
                    <div class="prince_contact-block">
                        <h5>Number</h5>
                        <p>+91-998-242-4661</p>

                    </div>
                    <div class="prince_contact-block">
                        <h5>Email</h5>
                        <p>info@princedetactive.com</p>

                    </div>
                    <div class="prince_contact-block">
                        <h5>Social Link</h5>


                    </div>
                    <div class="social-sec">
                        <ul class="list-inline w-100">

                            <li class="d-inline-block social px-1">
                                <a href="http://twitter.com"><i class="fab fa-twitter" aria-hidden="true"></i></a>
                            </li>
                            <li class="d-inline-block social px-1">
                                <a href="http://facebook.com"><i class="fab fa-facebook-f" aria-hidden="true"></i></a>
                            </li>
                            <li class="d-inline-block social px-1">
                                <a href="http://youtube.com"><i class="fab fa-youtube" aria-hidden="true"></i></a>
                            </li>
                            <li class="d-inline-block social px-1">
                                <a href="http://instagram.com"><i class="fab fa-instagram" aria-hidden="true"></i></a>
                            </li>
                            <li class="d-inline-block social px-1">
                                <a href="http://instagram.com"><i class="fab fa-google" aria-hidden="true"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
?>
<?php include("footer.php"); ?>