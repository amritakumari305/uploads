<?php
include("header.php");
include("menu.php");
?>


<section class="laro-sub-page-banner parallax" id="banner" style="background-position: 50% 0px;">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page-banner text-center">
                    <h1 class="sub-banner-title">Faq</h1>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li>Faq</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>



<div class="faq-part-2 py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2 wow fadeInUp">
                <div class="headings text-center">
                   
                    <h2 class="item-title">Frequently Asked Questions</h2>

                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-6">
                <div class="accordion-faq-box mb-3">
                    <a href="javascript:void(0)" class="accordion-faq-title">What is Ico Crypto?</a>
                    <div class="accordion-faq-content" style="display: none;">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged.</p>
                    </div>
                </div>
                <div class="accordion-faq-box mb-3">
                    <a href="javascript:void(0)" class="accordion-faq-title">How can I participate in the ICO Token sale?</a>
                    <div class="accordion-faq-content">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged.</p>
                    </div>
                </div>
                <div class="accordion-faq-box mb-3">
                    <a href="javascript:void(0)" class="accordion-faq-title">How can I participate in the ICO Token sale?</a>
                    <div class="accordion-faq-content">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged.</p>
                    </div>
                </div>
                <div class="accordion-faq-box mb-3">
                    <a href="javascript:void(0)" class="accordion-faq-title">How can I participate in the ICO Token sale?</a>
                    <div class="accordion-faq-content">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged.</p>
                    </div>
                </div>
                <div class="accordion-faq-box mb-3">
                    <a href="javascript:void(0)" class="accordion-faq-title">How can I participate in the ICO Token sale?</a>
                    <div class="accordion-faq-content">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged.</p>
                    </div>
                </div>
                <div class="accordion-faq-box mb-3">
                    <a href="javascript:void(0)" class="accordion-faq-title">How can I participate in the ICO Token sale?</a>
                    <div class="accordion-faq-content">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged.</p>
                    </div>
                </div>
                <div class="accordion-faq-box mb-3">
                    <a href="javascript:void(0)" class="accordion-faq-title">How can I participate in the ICO Token sale?</a>
                    <div class="accordion-faq-content">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="accordion-faq-box mb-3">
                    <a href="javascript:void(0)" class="accordion-faq-title">How can I participate in the ICO Token sale?</a>
                    <div class="accordion-faq-content">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged.</p>
                    </div>
                </div>
                <div class="accordion-faq-box mb-3">
                    <a href="javascript:void(0)" class="accordion-faq-title">How can I participate in the ICO Token sale?</a>
                    <div class="accordion-faq-content">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged.</p>
                    </div>
                </div>
                <div class="accordion-faq-box mb-3">
                    <a href="javascript:void(0)" class="accordion-faq-title">How can I participate in the ICO Token sale?</a>
                    <div class="accordion-faq-content">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged.</p>
                    </div>
                </div>
                <div class="accordion-faq-box mb-3">
                    <a href="javascript:void(0)" class="accordion-faq-title">How can I participate in the ICO Token sale?</a>
                    <div class="accordion-faq-content">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged.</p>
                    </div>
                </div>
                <div class="accordion-faq-box mb-3">
                    <a href="javascript:void(0)" class="accordion-faq-title">How can I participate in the ICO Token sale?</a>
                    <div class="accordion-faq-content">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged.</p>
                    </div>
                </div>
                <div class="accordion-faq-box mb-3">
                    <a href="javascript:void(0)" class="accordion-faq-title">How can I participate in the ICO Token sale?</a>
                    <div class="accordion-faq-content">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged.</p>
                    </div>
                </div>
                <div class="accordion-faq-box mb-3">
                    <a href="javascript:void(0)" class="accordion-faq-title">How can I participate in the ICO Token sale?</a>
                    <div class="accordion-faq-content">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. remaining essentially unchanged.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php include("footer.php") ?>