<?php
include("header.php");
include("menu.php");
?>


<section class="laro-sub-page-banner parallax" id="banner" style="background-position: 50% 0px;">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page-banner text-center">
                    <h1 class="sub-banner-title">Team</h1>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li>Team</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="team-part pb-4 pt-5">
    <div class="container">

        <div class="row">
            <div class="col-md-4 pb-4 wow fadeInLeft animated" style="visibility: visible;">
                <div class="team-box flex-align">
                    <div class="team-img">
                        <a href="team.php"><img src="assets/images/team1.jpg" alt="team member"></a>
                    </div>
                    <div class="team-des">
                        <a href="team.php" class="member-name">John Doe</a>
                        <p class="member-des">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor it amet, consectetur</p>

                    </div>
                </div>
            </div>
            <div class="col-md-4 pb-4 wow fadeInRight animated" style="visibility: visible;">
                <div class="team-box flex-align">
                    <div class="team-img">
                        <a href="team.php"><img src="assets/images/team1.jpg" alt="team member"></a>
                    </div>
                    <div class="team-des">
                        <a href="team.php" class="member-name">John Doe</a>
                        <p class="member-des">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor it amet, consectetur</p>

                    </div>
                </div>
            </div>
            <div class="col-md-4 pb-4 wow fadeInLeft animated" style="visibility: visible;">
                <div class="team-box flex-align">
                    <div class="team-img">
                        <a href="team.php"><img src="assets/images/team1.jpg" alt="team member"></a>
                    </div>
                    <div class="team-des">
                        <a href="team.php" class="member-name">John Doe</a>
                        <p class="member-des">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor it amet, consectetur</p>

                    </div>
                </div>
            </div>
            <div class="col-md-4 pb-4 wow fadeInRight animated" style="visibility: visible;">
                <div class="team-box flex-align">
                    <div class="team-img">
                        <a href="team.php"><img src="assets/images/team1.jpg" alt="team member"></a>
                    </div>
                    <div class="team-des">
                        <a href="team.php" class="member-name">John Doe</a>
                        <p class="member-des">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor it amet, consectetur</p>

                    </div>
                </div>
            </div>
            <div class="col-md-4 pb-4 wow fadeInRight animated" style="visibility: visible;">
                <div class="team-box flex-align">
                    <div class="team-img">
                        <a href="team.php"><img src="assets/images/team1.jpg" alt="team member"></a>
                    </div>
                    <div class="team-des">
                        <a href="team.php" class="member-name">John Doe</a>
                        <p class="member-des">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor it amet, consectetur</p>

                    </div>
                </div>
            </div>
            <div class="col-md-4 pb-4 wow fadeInRight animated" style="visibility: visible;">
                <div class="team-box flex-align">
                    <div class="team-img">
                        <a href="team.php"><img src="assets/images/team1.jpg" alt="team member"></a>
                    </div>
                    <div class="team-des">
                        <a href="team.php" class="member-name">John Doe</a>
                        <p class="member-des">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor it amet, consectetur</p>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>





<?php include("footer.php") ?>