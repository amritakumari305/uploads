<?php
include("header.php");
include("menu.php");
?>

<style>

</style>

<section class="laro-sub-page-banner">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page-banner text-center">
                    <h1 class="sub-banner-title">Roadmap</h1>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li>Roadmap</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="py-5">
    <div class="container">

        <ul class="timelines">
            <li>
                <div class="timelines-badge primary">
                    <a><i class="fa fa-rocket" rel="tooltip" title="11 hours ago via Twitter" id=""></i></a>
                </div>
                <div class="timelines-panel">
                    <div class="timelines-heading">
                        <p>2021</p>

                    </div>
                    <div class="timelines-body">
                        <h3 class="title">Phase 01</h3>
                        <h5>DxSale Presale</h5>
                        <div class="done">Done</div>
                        <p>Mussum ipsum cacilds, vidis litro abertis. Consetis adipiscings elitis. Pra lá , depois divoltis porris, paradis. Paisis, filhis, espiritis santis. Mé faiz elementum girarzis, nisi eros vermeio, in elementis mé pra quem é amistosis quis leo. Manduma pindureta quium dia nois paga. Sapien in monti palavris qui num significa nadis i pareci latim. Interessantiss quisso pudia ce receita de bolis, mais bolis eu num gostis.</p>

                    </div>


                    <div class="timelines-body">
                        <h3 class="title">Phase 01</h3>
                        <h5>DxSale Presale</h5>
                        <div class="done">Done</div>
                        <p>Mussum ipsum cacilds, vidis litro abertis. Consetis adipiscings elitis. Pra lá , depois divoltis porris, paradis. Paisis, filhis, espiritis santis. Mé faiz elementum girarzis, nisi eros vermeio, in elementis mé pra quem é amistosis quis leo. Manduma pindureta quium dia nois paga. Sapien in monti palavris qui num significa nadis i pareci latim. Interessantiss quisso pudia ce receita de bolis, mais bolis eu num gostis.</p>

                    </div>


                </div>
            </li>

            <li class="timelines-inverted">
                <div class="timelines-badge primary">
                    <a><i class="fa fa-rocket" rel="tooltip" title="11 hours ago via Twitter" id=""></i></a>
                </div>
                <div class="timelines-panel">
                    <div class="timelines-heading">
                        <p>2021</p>

                    </div>
                    <div class="timelines-body">
                        <h3 class="title">Phase 01</h3>
                        <h5>DxSale Presale</h5>
                        <div class="done">Done</div>
                        <p>Mussum ipsum cacilds, vidis litro abertis. Consetis adipiscings elitis. Pra lá , depois divoltis porris, paradis. Paisis, filhis, espiritis santis. Mé faiz elementum girarzis, nisi eros vermeio, in elementis mé pra quem é amistosis quis leo. Manduma pindureta quium dia nois paga. Sapien in monti palavris qui num significa nadis i pareci latim. Interessantiss quisso pudia ce receita de bolis, mais bolis eu num gostis.</p>

                    </div>


                    <div class="timelines-body">
                        <h3 class="title">Phase 01</h3>
                        <h5>DxSale Presale</h5>
                        <div class="done">Done</div>
                        <p>Mussum ipsum cacilds, vidis litro abertis. Consetis adipiscings elitis. Pra lá , depois divoltis porris, paradis. Paisis, filhis, espiritis santis. Mé faiz elementum girarzis, nisi eros vermeio, in elementis mé pra quem é amistosis quis leo. Manduma pindureta quium dia nois paga. Sapien in monti palavris qui num significa nadis i pareci latim. Interessantiss quisso pudia ce receita de bolis, mais bolis eu num gostis.</p>

                    </div>


                </div>
            </li>
            <li>
            <div class="timelines-badge primary">
                    <a><i class="fa fa-rocket" rel="tooltip" title="11 hours ago via Twitter" id=""></i></a>
                </div>
                <div class="timelines-panel">
                    <div class="timelines-heading">
                        <p>2021</p>

                    </div>
                    <div class="timelines-body">
                        <h3 class="title">Phase 01</h3>
                        <h5>DxSale Presale</h5>
                        <div class="done">Done</div>
                        <p>Mussum ipsum cacilds, vidis litro abertis. Consetis adipiscings elitis. Pra lá , depois divoltis porris, paradis. Paisis, filhis, espiritis santis. Mé faiz elementum girarzis, nisi eros vermeio, in elementis mé pra quem é amistosis quis leo. Manduma pindureta quium dia nois paga. Sapien in monti palavris qui num significa nadis i pareci latim. Interessantiss quisso pudia ce receita de bolis, mais bolis eu num gostis.</p>

                    </div>

                   
                    <div class="timelines-body">
                        <h3 class="title">Phase 01</h3>
                        <h5>DxSale Presale</h5>
                        <div class="done">Done</div>
                        <p>Mussum ipsum cacilds, vidis litro abertis. Consetis adipiscings elitis. Pra lá , depois divoltis porris, paradis. Paisis, filhis, espiritis santis. Mé faiz elementum girarzis, nisi eros vermeio, in elementis mé pra quem é amistosis quis leo. Manduma pindureta quium dia nois paga. Sapien in monti palavris qui num significa nadis i pareci latim. Interessantiss quisso pudia ce receita de bolis, mais bolis eu num gostis.</p>

                    </div>

                   
                </div>
            </li>

            <li class="timelines-inverted">
            <div class="timelines-badge primary">
                    <a><i class="fa fa-rocket" rel="tooltip" title="11 hours ago via Twitter" id=""></i></a>
                </div>
                <div class="timelines-panel">
                    <div class="timelines-heading">
                        <p>2021</p>

                    </div>
                    <div class="timelines-body">
                        <h3 class="title">Phase 01</h3>
                        <h5>DxSale Presale</h5>
                        <div class="done">Done</div>
                        <p>Mussum ipsum cacilds, vidis litro abertis. Consetis adipiscings elitis. Pra lá , depois divoltis porris, paradis. Paisis, filhis, espiritis santis. Mé faiz elementum girarzis, nisi eros vermeio, in elementis mé pra quem é amistosis quis leo. Manduma pindureta quium dia nois paga. Sapien in monti palavris qui num significa nadis i pareci latim. Interessantiss quisso pudia ce receita de bolis, mais bolis eu num gostis.</p>

                    </div>

                   
                    <div class="timelines-body">
                        <h3 class="title">Phase 01</h3>
                        <h5>DxSale Presale</h5>
                        <div class="done">Done</div>
                        <p>Mussum ipsum cacilds, vidis litro abertis. Consetis adipiscings elitis. Pra lá , depois divoltis porris, paradis. Paisis, filhis, espiritis santis. Mé faiz elementum girarzis, nisi eros vermeio, in elementis mé pra quem é amistosis quis leo. Manduma pindureta quium dia nois paga. Sapien in monti palavris qui num significa nadis i pareci latim. Interessantiss quisso pudia ce receita de bolis, mais bolis eu num gostis.</p>

                    </div>

                   
                </div>
            </li>
           

            <li class="clearfix" style="float: none;"></li>
        </ul>
    </div>
</section>

<!-- <section class="py-5">
    <div class="container-fluid">
       
        <div class="row">
            <div class="col-md-12">
                <div class="main-timeliness4">
                    <div class="timeliness">
                        <span class="timeliness-icon"></span>
                        <span class="year">2017</span>
                        <div class="timeliness-content">
                            <h3 class="title">Phase 01</h3>
                            <h5>DxSale Presale</h5>
                            <div class="done">Done</div>
                            <p class="description">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus mattis justo id pulvinar suscipit. Pellentesque rutrum vehicula erat sed dictum. Integer quis turpis magna. Suspendisse tincidunt elit at erat tincidunt, vel vulputate arcu dapibus. Etiam accumsan ornare posuere. Nullam est.
                            </p>
                        </div>
                    </div>
                    <div class="timeliness">
                        <span class="timeliness-icon"></span>
                        <span class="year">2016</span>
                        <div class="timeliness-content">
                            <h3 class="title">Web Developer</h3>
                            <p class="description">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus mattis justo id pulvinar suscipit. Pellentesque rutrum vehicula erat sed dictum. Integer quis turpis magna. Suspendisse tincidunt elit at erat tincidunt, vel vulputate arcu dapibus. Etiam accumsan ornare posuere. Nullam est.
                            </p>
                        </div>
                    </div>
                    <div class="timeliness">
                        <span class="timeliness-icon"></span>
                        <span class="year">2015</span>
                        <div class="timeliness-content">
                            <h3 class="title">Web Desginer</h3>
                            <p class="description">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus mattis justo id pulvinar suscipit. Pellentesque rutrum vehicula erat sed dictum. Integer quis turpis magna. Suspendisse tincidunt elit at erat tincidunt, vel vulputate arcu dapibus. Etiam accumsan ornare posuere. Nullam est.
                            </p>
                        </div>
                    </div>
                    <div class="timeliness">
                        <span class="timeliness-icon"></span>
                        <span class="year">2014</span>
                        <div class="timeliness-content">
                            <h3 class="title">Web Developer</h3>
                            <p class="description">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus mattis justo id pulvinar suscipit. Pellentesque rutrum vehicula erat sed dictum. Integer quis turpis magna. Suspendisse tincidunt elit at erat tincidunt, vel vulputate arcu dapibus. Etiam accumsan ornare posuere. Nullam est.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> -->


<?php include("footer.php") ?>