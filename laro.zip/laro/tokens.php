<?php
include("header.php");
include("menu.php");
?>


<section class="laro-sub-page-banner">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page-banner text-center">
                    <h1 class="sub-banner-title">Tokens</h1>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li>Tokens</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>



<section class="tokens-page py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="faq-tabs text-center">
                <div class="tokens-img mb-5 mt-3">
                                        <img src="assets/images/icons/i6.png" alt="">

                                    </div>
                                    <a href="#" class="qus-title">250,000,000,000,000</a>
                                    <p class="qus-des pt-4">Tokens not sold were burnt</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="faq-tabs text-center">
                <div class="tokens-img mb-5 mt-3">
                                        <img src="assets/images/icons/i7.png" alt="">

                                    </div>
                                    <a href="#" class="qus-title">250,000,000,000,000</a>
                                    <p class="qus-des pt-4">Tokens not sold were burnt</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="faq-tabs text-center">
                <div class="tokens-img mb-5 mt-3">
                                        <img src="assets/images/icons/i8.png" alt="">

                                    </div>
                                    <a href="#" class="qus-title">250,000,000,000,000</a>
                                    <p class="qus-des pt-4">Tokens not sold were burnt</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="faq-tabs text-center">
                <div class="tokens-img mb-5 mt-3">
                                        <img src="assets/images/icons/i9.png" alt="">

                                    </div>
                                    <a href="#" class="qus-title">250,000,000,000,000</a>
                                    <p class="qus-des pt-4">Tokens not sold were burnt</p>
                </div>
            </div>
            <div class="col-md-6 offset-3">
                <div class="faq-tabs text-center">
                <div class="tokens-img mb-5 mt-3">
                                        <img src="assets/images/icons/i10.png" alt="">

                                    </div>
                                    <a href="#" class="qus-title">2%</a>
                                    <p class="qus-des pt-4">Tokens not sold were burnt</p>
                </div>
            </div>

        </div>
    </div>
</section>



<?php include("footer.php") ?>