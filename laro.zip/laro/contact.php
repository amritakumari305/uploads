<?php
include("header.php");
include("menu.php");
?>


<section class="laro-sub-page-banner parallax" id="banner" style="background-position: 50% 0px;">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page-banner text-center">
                    <h1 class="sub-banner-title">Contact us</h1>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li>Contact us</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="contact-form py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6 wow fadeInLeft animated" style="visibility: visible;">
                <div class="section-heading">
                    <h2 class="heading-title-2 pb-4">Contact Us</h2>
                    <p class="heading-des">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. dolore eu fugiat nulla pariatur. </p>
                </div>
                <ul class="contact-detail">
                    <!-- <li><i class="fa fa-phone" aria-hidden="true"></i> <a href="tel:+91-989-789-6789"> +91-989-789-6789</a></li> -->
                    <li><i class="fa fa-envelope" aria-hidden="true"></i> <a href="mailto:support@laroenergy.com">support@laroenergy.com</a></li>
                    <li><i class="fa fa-map-marker" aria-hidden="true"></i> <span>Laro Energy</span></li>
                </ul>
            </div>
            <div class="col-md-6 wow fadeInRight animated" style="visibility: visible;">
                <h3 class="heading-title-2 pb-4 pt-4 pt-sm-0">Leave a message here</h3>
                <form method="POST">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Name*" required="">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Email*" required="">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Subject*" required="">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Phone*" required="">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <textarea class="form-control" placeholder="Massage*" required=""></textarea>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <button class="btn">submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        
    </div>
</section>


<?php include("footer.php") ?>