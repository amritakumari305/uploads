<?php
include("header.php");
include("menu.php");
?>


<section class="laro-sub-page-banner parallax" id="banner" style="background-position: 50% 0px;">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page-banner text-center">
                    <h1 class="sub-banner-title">Blog Details</h1>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li>Blog</li>
                        <li>Blog Details</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="blog-detail-main py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="blog-detail-img">
                    <img src="assets/images/blog/b1.jpg" alt="blog" width="100%">
                </div>
                <div class="blog-detail-content">
                    <ul>
                        <li>March 20,2019</li>
                        <li>by john Doe</li>
                    </ul>
                    <h2>Cryptocash is a clean, modern and itry-specific HTML template</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip</p>

                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                    <blockquote>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ipsum dolor</blockquote>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip orem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
                </div>
            </div>
        </div>
        <div class="blog-detail-tag-social">
            <div class="row">
                <div class="col-md-7">
                    <div class="blog-detail-tag">
                        <span>Tag by</span>
                        <ul>
                            <li><a href="#">Bitcoin</a></li>
                            <li><a href="#">Crypto</a></li>
                            <li><a href="#">Block chain</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-5">
                    
                </div>
            </div>
        </div>
        <div class="blog-comment-post-singel"></div>
        <div class="blog-comment-post">
            <h3 class="blog-comment-heading">3 Comments on this post</h3>
            <ul class="blog-comment-box">
                <li>
                    
                    <div class="blog-comment-content">
                        <h4 class="commenter">John Doe</h4>
                        <span class="comment-date">28 September 2021</span>
                        <p class="comment-des">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in finibus neque. Vivamus in ipsum quis elit vehicula tempus vitae quis lacus. Vestibulum.Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                        <a href="#" class="comment-reply">Reply <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                    </div>
                </li><hr>
                <li>
                    
                    <div class="blog-comment-content">
                        <h4 class="commenter">John Doe</h4>
                        <span class="comment-date">28 September 2021</span>
                        <p class="comment-des">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in finibus neque. Vivamus in ipsum quis elit vehicula tempus vitae quis lacus. Vestibulum.Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                        <a href="#" class="comment-reply">Reply <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                    </div>
                </li><hr>
                <li>
                    
                    <div class="blog-comment-content">
                        <h4 class="commenter">John Doe</h4>
                        <span class="comment-date">28 September 2021</span>
                        <p class="comment-des">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in finibus neque. Vivamus in ipsum quis elit vehicula tempus vitae quis lacus. Vestibulum.Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                        <a href="#" class="comment-reply">Reply <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                    </div>
                </li><hr>
            </ul>
        </div>
        <div class="leave-comment">
            <h3 class="blog-comment-heading">Leave a comment</h3>
            <form>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Your Name*" required="">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Your Email*" required="">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Your Phone*" required="">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <textarea class="form-control" placeholder="Review*" required=""></textarea>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <button class="btn">submit</button>
                    </div>
                </div>
            </form>
        </div>

    </div>
</section>

<?php include("footer.php") ?>