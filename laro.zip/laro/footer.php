
<footer class="bg-pattern pt-5">
    <div class="container">
        <div class="footer">
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="footer-logo pb-25">
                        <a href="index.php"><img src="assets/images/logo.png" alt="Laro" width="120"></a>
                    </div>
                    <p class="footer-para">Moving forward with a fully doxxed team is high priority for us. We want holders and community to feel confident in their investments and hope to provide as much transparency as possible!</p>
                    <div class="footer-icon mb-3 mb-lg-0">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
                            <li><a href="#"><i class="fa fa-telegram" aria-hidden="true"></i></a></li>
                            
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="footer-link">
                        <h3>Site Links</h3>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="about.php">About Us</a></li>
                            <li><a href="contact.php">Contact Us</a></li>
                            <li><a href="tokens.php">Tokens</a></li>
                            <li><a href="https://app.uniswap.org/#/swap">Buy Now</a></li>

                            <li><a href="blog.php">Blog</a></li>
                            <li><a href="roadmap.php">Roadmap</a></li>
                            <li><a href="team.php">Teams</a></li>
                            <li><a href="market.php">Market</a></li>
                            <li><a href="faq.php">Faq</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="footer-links">
                        <h3>Contact Us</h3>
                        <ul>
                            <li><a href="#"><i class="fa fa-map-marker"></i> Address : Laro Energy</a></li>
                            <!-- <li><a href="#"><i class="fa fa-phone"></i> Number : +91-989-789-6789</a></li> -->
                            <li><a href="#"><i class="fa fa-envelope-o"></i> E-mail : info@laroenergy.com</a></li>

                        </ul>
                    </div>
                    <p class="text-white">Subscribe to our Newsleter to get an Daily news and updates</p> 
                    <div class="subscribe">

                        
                        <div class="form-group">
                       
                            <label>Subscribe to our Newsleter</label>
                            <input type="email" class="form-control" placeholder="Enter your email Address">
                            <input type="submit" name="submit" value="Subscribe" class="submit">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright text-center text-md-left">
            <div class="row">
                <div class="col-lg-12">
                    <p>&copy; all Rights Reserved. Designed By
                        <a href="https://coralitsolution.com/"><img src="assets/images/coral-logo.png" width="150"></a>
                    </p>
                </div>

            </div>
        </div>
    </div>
</footer>
<!-- <script>
        $(document).ready(function() {

            $('.counter').each(function() {
                $(this).prop('Counter', 0).animate({
                    Counter: $(this).text()
                }, {
                    duration: 4000,
                    easing: 'swing',
                    step: function(now) {
                        $(this).text(Math.ceil(now));
                    }
                });
            });

        });
    </script> -->
<script>
    $(document).ready(function(){
	var my_posts = $("[rel=tooltip]");

	var size = $(window).width();
	for(i=0;i<my_posts.length;i++){
		the_post = $(my_posts[i]);

		if(the_post.hasClass('invert') && size >=767 ){
			the_post.tooltip({ placement: 'left'});
			the_post.css("cursor","pointer");
		}else{
			the_post.tooltip({ placement: 'rigth'});
			the_post.css("cursor","pointer");
		}
	}
});
</script>

<script src="assets/js/jquery.js"></script>
<script src="assets/js/bootstrap.js"></script>
<script src="assets/js/animation.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/snap.svg-min.js"></script>
<script src="assets/js/custom.js"></script>


</body>

</html>