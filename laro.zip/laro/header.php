<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Home Page descriptiopns -->
    <meta charset="utf-8">
    <!-- site title -->
    <title>Laro Energy</title>
    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link type="image/x-icon" href="assets/images/logo.png" rel="icon">

    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/css/animations.css">
    <!-- Font Awesome Css -->
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
    <!-- owl Carousel Css -->
    <link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.css">


</head>