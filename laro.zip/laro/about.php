<?php
include("header.php");
include("menu.php");
?>


<section class="laro-sub-page-banner parallax" id="banner" style="background-position: 50% 0px;">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page-banner text-center">
                    <h1 class="sub-banner-title">About us</h1>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li>About us</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>



<section class="pb-2 pt-4">
    <div class="container">
        <div class="row laro-counter">
            <!-- counter -->
            <div class="col-md-3 col-sm-6 col-6 bottom-margin text-center counter-section wow fadeInUp animated" data-wow-duration="300ms">
                <img src="assets/images/icons/i1.png" alt="">
                <span id="anim-number-pizza" class="counter-number"></span>
                <span class="timer counter alt-font appear" data-to="980" data-speed="7000">2800+</span>
                <p class="counter-title">Completed Projects</p>
            </div>
            <!-- end counter -->
            <!-- counter -->
            <div class="col-md-3 col-sm-6 col-6  bottom-margin text-center counter-section wow fadeInUp animated" data-wow-duration="600ms">
                <img src="assets/images/icons/i2.png" alt="">
                <span class="timer counter alt-font appear" data-to="980" data-speed="7000">980+</span>
                <p class="counter-title">Satisfied Clients</p>
            </div>
            <!-- end counter -->
            <!-- counter -->
            <div class="col-md-3 col-sm-6 col-6 bottom-margin-small text-center counter-section wow fadeInUp animated" data-wow-duration="900ms">
                <img src="assets/images/icons/i3.png" alt="">
                <span class="timer counter alt-font appear" data-to="1" data-speed="8">05+</span>
                <p class="counter-title">Total Experince</p>
            </div>
            <!-- end counter -->
            <!-- counter -->
            <div class="col-md-3 col-sm-6 col-6 text-center counter-section wow fadeInUp animated" data-wow-duration="1200ms">
                <img src="assets/images/icons/i4.png" alt="">
                <span class="timer counter alt-font appear" data-to="600" data-speed="7000">600+</span>
                <p class="counter-title">Team Members</p>
            </div>
            <!-- end counter -->
        </div>

    </div>
</section>

<section class="about-sec section-padding py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <div class="about-img">

                    <img src="assets/images/about1.png" alt="" width="100%">
                </div>
            </div>
            <div class="col-md-7">
                <div class="about-inr">
                    <div class="item-sub-title"> About Laro Energy</div>
                    <h2 class="item-title">Welcome To Laro Energy</h2>
                    <p class="title-para">
                        Crypterio is ICO and Cryptocurrency WordPress theme, that perfectly fits for any type of crypto-consulting project. With Crypterio theme you’ll get a powerful
                    </p>
                    <p class="about-p">
                        Crypterio is ready for a Smart Contract and an ICO Whitelist Pre-Signup integration through CSV/XML compatible standard to manage token distribution. Just integrate your Smart Contract with a Whitelist through CSV/XML to manage token distribution.
                    </p>

                    <div class="about-partition mt-4">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="first-part">
                                    <img src="assets/images/part1.png" alt="" width="50">
                                    <h4 class="my-2">Expert Team</h4>
                                    <p>Crypterio is ready for a Smart Contract and an ICO Whitelist Pre-Signup</p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="first-part">
                                    <img src="assets/images/part2.png" alt="" width="50">
                                    <h4 class="my-2">Target Fulfil</h4>
                                    <p>Crypterio is ready for a Smart Contract and an ICO Whitelist Pre-Signup</p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </div>

        <hr />
    </div>
</section>


<section class="mission-vison pt-3 pb-4">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="laro-mv">
                    <h3 class="about-title le-line-left" data-wow-delay="ms">
                        <span> <i></i>Our Mission</span>
                    </h3>
                    <p>Through strategic partnerships, academic backing, and a strong budding crypto currency community, we have bundled ingredients to significantly change the earth’s landscape through carbon</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="laro-mv">
                    <h3 class="about-title le-line-left" data-wow-delay="ms">
                        <span> <i></i>Our Vision</span>
                    </h3>
                    <p>Through strategic partnerships, academic backing, and a strong budding crypto currency community, we have bundled ingredients to significantly change the earth’s landscape through carbon</p>
                </div>
            </div>

            <div class="col-md-12 mt-5">
                <div class="see-instructions text-center">
                    <a class="btn btn-success" href="assets/images/WhitePaper.pdf" target="_blank">View how to buy instruction</a>
                </div>
            </div>
        </div>
    </div>
</section>


<?php include("footer.php") ?>