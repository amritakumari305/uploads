<?php
include("header.php");
include("menu.php");
?>


<section class="laro-sub-page-banner parallax" id="banner" style="background-position: 50% 0px;">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page-banner text-center">
                    <h1 class="sub-banner-title">Blog</h1>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li>Blog</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>



<section class="blog-list-main py-5">
    <div class="container">
        <div class="row">
            <div class="col-xl-4 col-lg-4 col-md-12 order-r-2">
               
                <div class="blog-category mb-4">
                    <h2 class="blog-cat-title">Category</h2>
                    <ul>
                        <li><a href="blog-detail.php">Laro Energy</a></li>
                        <li><a href="blog-detail.php">Crypto Currency</a></li>
                        <li><a href="blog-detail.php">Soloar Energy</a></li>
                        <li><a href="blog-detail.php">Plantation</a></li>
                        <li><a href="blog-detail.php">Wind Energy</a></li>
                    </ul>
                </div>
                <div class="trending-news mb-4">
                    <h2 class="blog-cat-title">Trending News</h2>
                    <div class="trending-news-box mb-3">
                        <div class="trending-news-img">
                            <a href="#"><img src="assets/images/blog/b3.jpg" class="transition" alt="Trending News"></a>
                        </div>
                        <div class="trending-news-content">
                            <a href="#" class="trending-news-title">Finance Minister Calls of ICO.</a>
                            <span class="trending-news-date">March 20,2019</span>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="trending-news-box mb-3">
                        <div class="trending-news-img">
                            <a href="#"><img src="assets/images/blog/b3.jpg" class="transition" alt="Trending News"></a>
                        </div>
                        <div class="trending-news-content">
                            <a href="#" class="trending-news-title">Finance Minister Calls of ICO.</a>
                            <span class="trending-news-date">March 20,2019</span>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="trending-news-box mb-3">
                        <div class="trending-news-img">
                            <a href="#"><img src="assets/images/blog/b3.jpg" class="transition" alt="Trending News"></a>
                        </div>
                        <div class="trending-news-content">
                            <a href="#" class="trending-news-title">Finance Minister Calls of ICO.</a>
                            <span class="trending-news-date">March 20,2019</span>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="blog-tags mb-4">
                    <h2 class="blog-cat-title">Trending News</h2>
                    <ul>
                        <li><a href="javascript:void(0)">Crypto</a></li>
                        <li><a href="javascript:void(0)">Bitcoin</a></li>
                        <li><a href="javascript:void(0)">Plantation</a></li>
                        <li><a href="javascript:void(0)">Wind Energy</a></li>
                        <li><a href="javascript:void(0)">Solar Energy</a></li>
                        <li><a href="javascript:void(0)">Donate</a></li>
                        <li><a href="javascript:void(0)">Nature</a></li>
                        
                    </ul>
                </div>
                <div class="archives">
                    <h2 class="blog-cat-title">Archives</h2>
                    <ul>
                        <li><a href="#">September 2021</a></li>
                        <li><a href="#">September 2021</a></li>
                        <li><a href="#">September 2021</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-xl-8 col-lg-8 col-md-12 order-r-1">
                <div class="blog-list-box">
                    <div class="blog-list-img">
                        <a href="blog-detail.php"><img src="assets/images/blog/b1.jpg" class="transition" alt="blog"></a>
                    </div>
                    <div class="blog-list-content">
                        <a href="blog-detail.php" class="blog-list-title">Cryptocash is a clean, modern and itry-specific HTML template</a>
                        <ul>
                            <li>March 20,2019</li>
                            <li>by john Doe</li>
                        </ul>
                        <p class="blog-list-des">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip </p>
                        <a href="blog-detail.php" class="read-more">Read More</a>
                    </div>
                </div>
                <div class="blog-list-box">
                    <div class="blog-list-img">
                        <a href="blog-detail.php"><img src="assets/images/blog/b2.jpg" class="transition" alt="blog"></a>
                    </div>
                    <div class="blog-list-content">
                        <a href="blog-detail.php" class="blog-list-title">Cryptocash is a clean, modern and itry-specific HTML template</a>
                        <ul>
                            <li>March 20,2019</li>
                            <li>by john Doe</li>
                        </ul>
                        <p class="blog-list-des">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip </p>
                        <a href="blog-detail.php" class="read-more">Read More</a>
                    </div>
                </div>
                <div class="blog-list-box">
                    <div class="blog-list-img">
                        <a href="blog-detail.php"><img src="assets/images/blog/b3.jpg" class="transition" alt="blog"></a>
                    </div>
                    <div class="blog-list-content">
                        <a href="blog-detail.php" class="blog-list-title">Cryptocash is a clean, modern and itry-specific HTML template</a>
                        <ul>
                            <li>March 20,2019</li>
                            <li>by john Doe</li>
                        </ul>
                        <p class="blog-list-des">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip </p>
                        <a href="blog-detail.php" class="read-more">Read More</a>
                    </div>
                </div>

                <div class="blog-list-pagination">
                    <ul>
                        <li><a href="#" class="active">1</a></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>


<?php include("footer.php") ?>