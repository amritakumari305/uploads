<div class="social-buttons"> 
	<!-- facebook  Button -->
	<a href="#" class="s_icon facebook" id="fb_icon"><i class="fa fa-facebook-f" aria-hidden="true"></i></a>
	<a href="#" class="s_icon twitter" id="tw_icon"><i class="fa fa-twitter" aria-hidden="true"></i></a> 
	<a href="#" class="s_icon google" id="pin_icon"><i class="fa fa-pinterest" aria-hidden="true"></i></a> 
	<a href="#" class="s_icon linkedin" id="linke_icon"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
	<a href="#" class="s_icon youtube" id="you_icon"><i class="fa fa-youtube" aria-hidden="true"></i></a>
	<a href="#" class="s_icon instagram" id="insta_icon"><i class="fa fa-instagram" aria-hidden="true"></i></a>
	<a href="#" class="s_icon google" id="google_icon"><i class="fa fa-google" aria-hidden="true"></i></a>
    <a href="#" class="s_icon telegram" id="tele_icon"><i class="fa fa-telegram" aria-hidden="true"></i></a>
	<a class="s_icon whatsapp" id="watspp_icon" title="Send Message on whatsapp using your phone" href="https://api.whatsapp.com/send?phone=+919694270187"><i class="fa fa-whatsapp" aria-hidden="true"></i></a> 
</div>

<section class="home-banner" id="banner">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 flex-align wow fadeInLeft animated" style="visibility: visible;">
                <div class="banner-contain text-center text-md-left">
                    <h1 class="banner-heading">Invest In <span>Laro Energy</span> Way To Trade</h1>
                    <p class="banner-des">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem</p>
                    <a href="https://dex.guru/token/0xdbaaa36b347d56b77ce0e36f050fceebbf9fbc38-bsc" target="_blank" class="btn">Chart</a>
                    <a href="https://app.uniswap.org/#/swap" class="btn">Buy Now</a>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="banner-img">
                    <img src="assets/images/about-2.png" alt="banner">
                </div>
            </div>
        </div>
    </div>
</section>




<section class="about-sec section-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <div class="about-img">

                    <img src="assets/images/about1.png" alt="" width="100%">
                </div>
            </div>
            <div class="col-md-7">
                <div class="about-inr">
                    <div class="item-sub-title"> About Laro Energy</div>
                    <h2 class="item-title">Welcome To Laro Energy</h2>
                    <p class="title-para">
                        Crypterio is ICO and Cryptocurrency WordPress theme, that perfectly fits for any type of crypto-consulting project. With Crypterio theme you’ll get a powerful
                    </p>
                    <p class="about-p">
                        Crypterio is ready for a Smart Contract and an ICO Whitelist Pre-Signup integration through CSV/XML compatible standard to manage token distribution. Just integrate your Smart Contract with a Whitelist through CSV/XML to manage token distribution.
                    </p>

                    <div class="about-partition mt-4">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="first-part">
                                    <img src="assets/images/part1.png" alt="" width="50">
                                    <h4 class="my-2">Expert Team</h4>
                                    <p>Crypterio is ready for a Smart Contract and an ICO Whitelist Pre-Signup</p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="first-part">
                                    <img src="assets/images/part2.png" alt="" width="50">
                                    <h4 class="my-2">Target Fulfil</h4>
                                    <p>Crypterio is ready for a Smart Contract and an ICO Whitelist Pre-Signup</p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>


    </div>
</section>




<section class="pb-2">
    <div class="container">
        <div class="row laro-counter">
            <!-- counter -->
            <div class="col-md-3 col-sm-6 col-6 bottom-margin text-center counter-section wow fadeInUp animated" data-wow-duration="300ms">
                <img src="assets/images/icons/i1.png" alt="">
                <span id="anim-number-pizza" class="counter-number"></span>
                <span class="timer counter alt-font appear" data-to="980" data-speed="7000">2800+</span>
                <p class="counter-title">Completed Projects</p>
            </div>
            <!-- end counter -->
            <!-- counter -->
            <div class="col-md-3 col-sm-6 col-6  bottom-margin text-center counter-section wow fadeInUp animated" data-wow-duration="600ms">
                <img src="assets/images/icons/i2.png" alt="">
                <span class="timer counter alt-font appear" data-to="980" data-speed="7000">980+</span>
                <p class="counter-title">Satisfied Clients</p>
            </div>
            <!-- end counter -->
            <!-- counter -->
            <div class="col-md-3 col-sm-6 col-6 bottom-margin-small text-center counter-section wow fadeInUp animated" data-wow-duration="900ms">
                <img src="assets/images/icons/i3.png" alt="">
                <span class="timer counter alt-font appear" data-to="1" data-speed="8">05+</span>
                <p class="counter-title">Total Experince</p>
            </div>
            <!-- end counter -->
            <!-- counter -->
            <div class="col-md-3 col-sm-6 col-6 text-center counter-section wow fadeInUp animated" data-wow-duration="1200ms">
                <img src="assets/images/icons/i4.png" alt="">
                <span class="timer counter alt-font appear" data-to="600" data-speed="7000">600+</span>
                <p class="counter-title">Team Members</p>
            </div>
            <!-- end counter -->
        </div>

    </div>
</section>


<section class="project pt-4 pb-5">
    <div class="container">
        <div class="row">

            <div class="col-lg-5 col-md-12 col-sm-12 col-12">
                <div class="about-inr project-inner">
                    <div class="item-sub-title"> Our Project </div>
                    <h2 class="item-title text-white">Laro Energy Project</h2>
                    <p class="title-paras">
                        Crypterio is ICO and Cryptocurrency WordPress theme, that perfectly fits for any type of crypto-consulting project. With Crypterio theme you’ll get a powerful
                    </p>

                    <div class="signin d-inline-block mt-3">
                        <a href="#" class="btn">Explore More</a>
                    </div>

                </div>
            </div>

           
            <div class="col-lg-7 col-md-12 col-sm-12 col-12">
                <div class="row project-section">
                    <div class="col-md-6 col-sm-6 col-12">
                        <div class="project-box">
                            <i class="fa fa-user"></i>
                            <h4>Solar Energy</h4>
                            <p>Bitcoin Core, however, is a full node, meaning it helps verify and transmit other Bitcoin transactions across the network and stores copy of the entire blockchain.</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-12">
                        <div class="project-box  box-top-m">
                            <i class="fa fa-user"></i>
                            <h4>Wind Energy</h4>
                            <p>Bitcoin Core, however, is a full node, meaning it helps verify and transmit other Bitcoin transactions across the network and stores copy of the entire blockchain.</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-12">
                        <div class="project-box">
                            <i class="fa fa-user"></i>
                            <h4>Plantation</h4>
                            <p>Bitcoin Core, however, is a full node, meaning it helps verify and transmit other Bitcoin transactions across the network and stores copy of the entire blockchain.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="document-section pt-4 pb-4">
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2 wow fadeInUp">
                <div class="headings text-center">
                    <div class="item-sub-title"> Our Files</div>
                    <h2 class="item-title">Documents</h2>
                    <p class="title-para">
                        Crypterio is ICO and Cryptocurrency WordPress theme, that perfectly fits for any type of crypto-consulting project. With Crypterio theme you’ll get a powerful
                    </p>
                </div>
            </div>
        </div>


        <div class="row mt-5">
            <div class="col-md-4 col-sm-4 ">
                <div class="doc-inr">
                    <a href="assets/images/WhitePaper.pdf" target="_blank">
                        <img src="assets/images/icons/i5.png" alt="">
                        <h5>White Papers</h5>
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-4">
                <div class="doc-inr">
                    <a href="assets/images/WhitePaper.pdf" target="_blank">
                        <img src="assets/images/icons/i5.png" alt="">
                        <h5>Certik Audit</h5>
                    </a>
                </div>
            </div>
            <div class="col-md-4 col-sm-4">
                <div class="doc-inr">
                    <a href="assets/images/WhitePaper.pdf" target="_blank">
                        <img src="assets/images/icons/i5.png" alt="">
                        <h5>TechRate Audit</h5>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>




<section class="timeline lightskyblue">
    <div class="container">
        <div class="row wow fadeInLeft">

            <div class="col-md-8 offset-md-2">
                <div class="headings text-center">
                    <div class="item-sub-title"> Roadmap</div>
                    <h2 class="item-title text-white">The Timeline</h2>
                    <p class="title-para" style="color: #bdbdbd;">Cryptominded is a curated directory of the best cryptocurrency resources. We’re slowly transforming the website into the best place for beginners to learn about cryptocurrencies</p>
                </div>
            </div>
        </div>
        <div class="main-roadmap mt-5">
            <div class="row">
                <div class="col-md-12">
                    <div class="h-border wow fadeInLeft"></div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="roadmap-slider owl-carousel">
                        <div class="roadmap wow fadeInLeft">
                            <div class="roadmap-box text-center">
                                <div class="date-title">March 2021</div>
                                <div class="map-graphic">
                                    <div class="small-round"><span></span></div>
                                    <div class="v-row"></div>
                                </div>
                                <div class="roadmap-detail-box">
                                    <p>Lorem Ipsum has been the industry's standard dummy text </p>
                                </div>
                            </div>
                        </div>
                        <div class="roadmap wow fadeInLeft">
                            <div class="roadmap-box text-center">
                                <div class="date-title">April 2021</div>
                                <div class="map-graphic">
                                    <div class="small-round"><span></span></div>
                                    <div class="v-row"></div>
                                </div>
                                <div class="roadmap-detail-box">
                                    <p>Lorem Ipsum has been the industry's standard dummy text </p>
                                </div>
                            </div>
                        </div>
                        <div class="roadmap wow fadeInLeft">
                            <div class="roadmap-box text-center">
                                <div class="date-title">May 2021</div>
                                <div class="map-graphic">
                                    <div class="small-round"><span></span></div>
                                    <div class="v-row"></div>
                                </div>
                                <div class="roadmap-detail-box">
                                    <p>Lorem Ipsum has been the industry's standard dummy text </p>
                                </div>
                            </div>
                        </div>
                        <div class="roadmap wow fadeInLeft">
                            <div class="roadmap-box text-center">
                                <div class="date-title">June 2021</div>
                                <div class="map-graphic">
                                    <div class="small-round"><span></span></div>
                                    <div class="v-row"></div>
                                </div>
                                <div class="roadmap-detail-box">
                                    <p>Lorem Ipsum has been the industry's standard dummy text </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>




<section class="faq-part pt-3 pb-4">
    <div class="container">
        <div class="ct-particle-animate">

            <div class="tokens-img"> <img alt="" src="assets/images/bg/section-shape-01.png"></div>
        </div>
        <div class="row">

            <div class="col-md-8 offset-md-2 wow fadeInUp">
                <div class="headings text-center">
                    <div class="item-sub-title"> About Token</div>
                    <h2 class="item-title">Basic Tokenomics</h2>
                    <p class="title-para">
                        Crypterio is ICO and Cryptocurrency WordPress theme, that perfectly fits for any type of crypto-consulting project. With Crypterio theme you’ll get a powerful
                    </p>
                </div>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-md-12 wow fadeInUp">
                <ul class="nav nav-tabs Frequently-tabs pb-5" id="myTab" role="tablist">
                    <li>
                        <a class="active" data-toggle="tab" href="#general" role="tab">Total Supply</a>
                    </li>
                    <li>
                        <a data-toggle="tab" href="#ico" role="tab">Tokens Burnt</a>
                    </li>
                    <li>
                        <a data-toggle="tab" href="#Tokens" role="tab">Pre Sale</a>
                    </li>
                    <li>
                        <a data-toggle="tab" href="#client" role="tab">PCS LP</a>
                    </li>
                    <li>
                        <a data-toggle="tab" href="#legal" role="tab">Rewards</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 wow fadeInUp">
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="general" role="tabpanel">
                        <div class="row">
                            <div class="col-md-8 offset-md-2">
                                <div class="faq-tab text-center">
                                    <div class="tokens-img mb-5 mt-3">
                                        <img src="assets/images/icons/i6.png" alt="">

                                    </div>
                                    <a href="#" class="qus-title">250,000,000,000,000</a>
                                    <p class="qus-des pt-4">Tokens not sold were burnt</p>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="tab-pane fade" id="ico" role="tabpanel">
                        <div class="row">
                            <div class="col-md-8 offset-md-2">
                                <div class="faq-tab text-center">
                                    <div class="tokens-img mb-5 mt-3">
                                        <img src="assets/images/icons/i7.png" alt="">

                                    </div>
                                    <a href="#" class="qus-title">250,000,000,000,000</a>
                                    <p class="qus-des pt-4">Tokens not sold were burnt</p>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="tab-pane fade" id="Tokens" role="tabpanel">
                        <div class="row">
                            <div class="col-md-8 offset-md-2">
                                <div class="faq-tab text-center">
                                    <div class="tokens-img mb-5 mt-3">
                                        <img src="assets/images/icons/i8.png" alt="">

                                    </div>
                                    <a href="#" class="qus-title">250,000,000,000,000</a>
                                    <p class="qus-des pt-4">Tokens not sold were burnt</p>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="tab-pane fade" id="client" role="tabpanel">
                        <div class="row">
                            <div class="col-md-8 offset-md-2">
                                <div class="faq-tab text-center">
                                    <div class="tokens-img mb-5 mt-3">
                                        <img src="assets/images/icons/i9.png" alt="">

                                    </div>
                                    <a href="#" class="qus-title">250,000,000,000,000</a>
                                    <p class="qus-des pt-4">Tokens not sold were burnt</p>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="tab-pane fade" id="legal" role="tabpanel">
                        <div class="row">
                            <div class="col-md-8 offset-md-2">
                                <div class="faq-tab text-center">
                                    <div class="tokens-img mb-5 mt-3">
                                        <img src="assets/images/icons/i10.png" alt="">

                                    </div>
                                    <a href="#" class="qus-title">250,000,000,000,000</a>
                                    <p class="qus-des pt-4">Tokens not sold were burnt</p>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

</section>




<section class="token-sale pt-5">
    <div class="container">
        <div class="row">

            <div class="col-md-8 offset-md-2 wow fadeInLeft">
                <div class="headings text-center">
                    <div class="item-sub-title">Testimonials</div>
                    <h2 class="item-title">What Client Say's </h2>
                    <p class="title-para">
                        Crypterio is ICO and Cryptocurrency WordPress theme, that perfectly fits for any type of crypto-consulting project. With Crypterio theme you’ll get a powerful
                    </p>
                </div>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-lg-8 offset-md-2 wow fadeInLeft flex-align">
                <div class="team-slider owl-carousel text-center">
                    <div class="testimonial-box wow fadeInUp">

                        <div class="test-img">
                            <img src="assets/images/bg/star.png" alt="" width="150">
                        </div>
                        <p><q>
                            Crypterio is ICO and Cryptocurrency WordPress theme, that perfectly fits for any type of crypto-consulting project. With Crypterio theme you’ll get a powerful
                        </q></p>
                        <h5>Kanye West</h5>

                    </div>
                    <div class="testimonial-box wow fadeInUp">
                        <div class="test-img">
                            <img src="assets/images/bg/star.png" alt="" width="150">
                        </div>
                        <p><q>
                            Crypterio is ICO and Cryptocurrency WordPress theme, that perfectly fits for any type of crypto-consulting project. With Crypterio theme you’ll get a powerful
                        </q></p>
                        <h5>Kany West</h5>

                    </div>
                    <div class="testimonial-box wow fadeInUp">
                        <div class="test-img">
                            <img src="assets/images/bg/star.png" alt="" width="150">
                        </div>
                        <p><q>
                            Crypterio is ICO and Cryptocurrency WordPress theme, that perfectly fits for any type of crypto-consulting project. With Crypterio theme you’ll get a powerful
                        </q></p>
                        <h5>Kanye West</h5>

                    </div>
                    <div class="testimonial-box wow fadeInUp">
                        <div class="test-img">
                            <img src="assets/images/bg/star.png" alt="" width="150">
                        </div>
                        <p><q>
                            Crypterio is ICO and Cryptocurrency WordPress theme, that perfectly fits for any type of crypto-consulting project. With Crypterio theme you’ll get a powerful
                        </q></p>
                        <h5>North West</h5>

                    </div>
                    <div class="testimonial-box wow fadeInUp">
                        <div class="test-img">
                            <img src="assets/images/bg/star.png" alt="" width="150">
                        </div>
                        <p><q>
                            Crypterio is ICO and Cryptocurrency WordPress theme, that perfectly fits for any type of crypto-consulting project. With Crypterio theme you’ll get a powerful
                        </q></p>
                        <h5>East West</h5>

                    </div>
                    <div class="testimonial-box wow fadeInUp">
                        <div class="test-img">
                            <img src="assets/images/bg/star.png" alt="" width="150">
                        </div>
                        <p><q>
                            Crypterio is ICO and Cryptocurrency WordPress theme, that perfectly fits for any type of crypto-consulting project. With Crypterio theme you’ll get a powerful
                        </q></p>
                        <h5>West West</h5>

                    </div>

                    <div class="testimonial-box wow fadeInUp">
                        <div class="test-img">
                            <img src="assets/images/bg/star.png" alt="" width="150">
                        </div>
                        <p><q>
                            Crypterio is ICO and Cryptocurrency WordPress theme, that perfectly fits for any type of crypto-consulting project. With Crypterio theme you’ll get a powerful
                        </q></p>
                        <h5>Wests West</h5>

                    </div>
                </div>
            </div>

        </div>
    </div>
</section>




<section class="blog-part pt-5">
    <div class="container">
        <div class="row">

            <div class="col-md-8 offset-md-2 wow fadeInLeft">
                <div class="headings text-center">
                    <div class="item-sub-title">News</div>
                    <h2 class="item-title">Our Blog </h2>
                    <p class="title-para">
                        Crypterio is ICO and Cryptocurrency WordPress theme, that perfectly fits for any type of crypto-consulting project. With Crypterio theme you’ll get a powerful
                    </p>
                </div>
            </div>
        </div>

        <div class="blog-slider owl-carousel mt-4">
            <div class="blog-box">
                <div class="blog-img mb-15">
                    <a href="blog-detail.php"><img src="assets/images/blog/b1.jpg" alt="blog"></a>
                </div>
                <div class="blog-des-box">
                    <a href="blog-detail.php" class="blog-title">Cryptocash is a clean, modern template clean</a>
                    <ul class="blog-date">
                        <li>28 September 2021</li>
                        <li><b>by :</b> john doe</li>
                    </ul>
                    <p class="blog-des">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur </p>
                    <a href="blog-detail.php" class="read-more">Read More</a>
                </div>
            </div>
            <div class="blog-box">
                <div class="blog-img mb-15">
                    <a href="blog-detail.php"><img src="assets/images/blog/b2.jpg" alt="blog"></a>
                </div>
                <div class="blog-des-box">
                    <a href="blog-detail.php" class="blog-title">Cryptocash is a clean, modern template clean</a>
                    <ul class="blog-date">
                        <li>28 September 2021</li>
                        <li><b>by :</b> john doe</li>
                    </ul>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur </p>
                    <a href="blog-detail.php" class="read-more">Read More</a>
                </div>
            </div>
            <div class="blog-box">
                <div class="blog-img mb-15">
                    <a href="blog-detail.php"><img src="assets/images/blog/b3.jpg" alt="blog"></a>
                </div>
                <div class="blog-des-box">
                    <a href="blog-detail.php" class="blog-title">Cryptocash is a clean, modern template clean</a>
                    <ul class="blog-date">
                        <li>28 September 2021</li>
                        <li><b>by :</b> john doe</li>
                    </ul>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur </p>
                    <a href="blog-detail.php" class="read-more">Read More</a>
                </div>
            </div>
            <div class="blog-box">
                <div class="blog-img mb-15">
                    <a href="blog-detail.php"><img src="assets/images/blog/b1.jpg" alt="blog"></a>
                </div>
                <div class="blog-des-box">
                    <a href="blog-detail.php" class="blog-title">Cryptocash is a clean, modern template clean</a>
                    <ul class="blog-date">
                        <li>28 September 2021</li>
                        <li><b>by :</b> john doe</li>
                    </ul>
                    <p class="blog-des">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur </p>
                    <a href="blog-detail.php" class="read-more">Read More</a>
                </div>
            </div>
            <div class="blog-box">
                <div class="blog-img mb-15">
                    <a href="blog-detail.php"><img src="assets/images/blog/b2.jpg" alt="blog"></a>
                </div>
                <div class="blog-des-box">
                    <a href="blog-detail.php" class="blog-title">Cryptocash is a clean, modern template clean</a>
                    <ul class="blog-date">
                        <li>28 September 2021</li>
                        <li><b>by :</b> john doe</li>
                    </ul>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur </p>
                    <a href="blog-detail.php" class="read-more">Read More</a>
                </div>
            </div>

            <div class="blog-box">
                <div class="blog-img mb-15">
                    <a href="blog-detail.php"><img src="assets/images/blog/b3.jpg" alt="blog"></a>
                </div>
                <div class="blog-des-box">
                    <a href="blog-detail.php" class="blog-title">Cryptocash is a clean, modern template clean</a>
                    <ul class="blog-date">
                        <li>28 September 2021</li>
                        <li><b>by :</b> john doe</li>
                    </ul>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do Lorem ipsum dolor sit amet, consectetur </p>
                    <a href="blog-detail.php" class="read-more">Read More</a>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="support-ptroject py-4">
    <div class="container">
        <div class="row">

            <div class="col-md-8 offset-md-2 wow fadeInLeft">
                <div class="headings text-center">

                    <h2 class="item-title">Support The Project</h2>
                    <p class="title-para">
                        We're not a charity token, but we accept donations towards the work we're doing to develop the project and help preserve the environment. This is the official SavePlanetEarth ERC20/BEP20 address for crypto donations, all forms of crypto are accepted.
                    </p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="donate-code text-center">
                    <script>
                        function copyToClipboard(element) {
                            var $temp = $("<input>");
                            $("body").append($temp);
                            $temp.val($(element).text()).select();
                            document.execCommand("copy");
                            $temp.remove();
                        }
                    </script>

                    <p id="text" style="word-break: break-all;">0x51E6d08721401f2ec874C996fcE0f1bCBF9317c8</p>
                    <button onclick="copyToClipboard('#text')"><i class="fa fa-file"></i></button>
                </div>
            </div>
        </div>
    </div>

    <!-- <div class="rounded_shape rounded_shape2"></div> -->
</section>