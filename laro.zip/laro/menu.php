<body>
    <header class="laro-header">
        <div class="container">
            <div class="row">

                <div class="col-lg-12">
                    <nav class="navbar navbar-expand-lg p-0">
                        <a class="navbar-brand" href="index.php"><img src="assets/images/logo2.png" alt="logo" width="100"></a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNavDropdown">
                            <ul class="navbar-nav mx-auto  mt-3">
                                <li class="nav-item active">
                                    <a class="nav-link" href="about.php">About <span class="sr-only">(current)</span></a>
                                </li>
                               
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Documents
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                        <a class="dropdown-item" href="assets/images/WhitePaper.pdf" target="_blank">Whitepaper</a>
                                        <a class="dropdown-item" href="https://www.certik.org/projects/saveplanetearth" target="_blank">Certik Audit</a>
                                        <a class="dropdown-item" href="assets/images/WhitePaper.pdf" target="_blank">TechRate Audit</a>
                                    </div>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="roadmap.php">Road Map</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="tokens.php">Tokens</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="team.php">Team</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="market.php">Market</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="blog.php">Blog</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="contact.php">Contact</a>
                                </li>
                            </ul>
                            <div class="signin d-inline-block mb-3 mb-lg-0">
                                <a href="https://app.uniswap.org/#/swap" class="btn">Buy Now</a>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>








