<?php
include("header.php");
include("menu.php");
?>


<section class="laro-sub-page-banner">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page-banner text-center">
                    <h1 class="sub-banner-title">Market</h1>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li>Market</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="market pb-4 pt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <h2 class="item-title" style="word-break: break-all;">Laro Energy Markets</h2>
                <p class="title-para">
                    Crypterio is ICO and Cryptocurrency WordPress theme, that perfectly fits for any type of crypto-consulting project. With Crypterio theme you’ll get a powerful
                </p>
                <hr>
            </div>

            <div class="col-md-8 offset-md-2">
                <div class="trading-section">
                    <h4>Featured</h4>
                    <h2>BitMart</h2>
                    <p class="title-para">A Premier Global Digital Assets Exchange, BitMart is a centralized exchange based in the Cayman Islands. It also has four offices located in New York, China, Hong Kong, and Seoul. It supports spot trading, OTC trading, and USD trading. Serving 180+ countries with more than 5,000,000 customers served, it reaches daily volumes of well over $1 billion and currently has 230+ coins/tokens available for trading.</p>
                    <div class="signin d-inline-block mb-3 mb-lg-0">
                        <a href="https://www.bitmart.com/trade/en?layout=basic&symbol=SPE_USDT" targer="_blank" class="btn">Start Trading</a>
                    </div>
                </div>
            </div>

            <div class="col-md-8 offset-md-2">
                <div class="market-table-sec mt-4">
                    <table class="market-table">
                        <thead>
                            <tr class="mrket-heading">
                                <th></th>
                                <th>Name</th>
                                <th class="mr-head-right">Pair</th>
                                <th class="mr-head-right">Listed</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><img src="assets/images/market/1.png" alt="" width="25"></td>
                                <td><a target="_blank" href="https://www.bitmart.com/trade/en?layout=basic&amp;symbol=SPE_USDT">BitMart <i class="fa fa-external-link"></i></a></td>
                                <td class="mr-head-right">USDT</td>
                                <td class="mr-head-right">05.25.2021</td>
                            </tr>
                            <tr>
                                <td><img src="assets/images/market/2.png" alt="" width="25"></td>
                                <td><a target="_blank" href="https://www.hotbit.io/exchange?symbol=SPE_USDT">HotBit <i class="fa fa-external-link"></i></a></td>
                                <td class="mr-head-right">USDT</td>
                                <td class="mr-head-right">05.25.2021</td>
                            </tr>
                            <tr>
                                <td><img src="assets/images/market/3.png" alt="" width="25"></td>
                                <td><a target="_blank" href="https://www.cointiger.com/en-us/#/trade_center?coin=spe_usdt">CoinTiger <i class="fa fa-external-link"></i></a></td>
                                <td class="mr-head-right">USDT</td>
                                <td class="mr-head-right">05.25.2021</td>
                            </tr>
                            <tr>
                                <td><img src="assets/images/market/4.png" alt="" width="20"></td>
                                <td><a target="_blank" href="https://whitebit.com/trade/SPE_DECL">WhiteBit <i class="fa fa-external-link"></i></a></td>
                                <td class="mr-head-right">USDT</td>
                                <td class="mr-head-right">05.25.2021</td>
                            </tr>
                            <tr>
                                <td><img src="assets/images/market/5.png" alt="" width="20"></td>
                                <td><a target="_blank" href="https://v1exchange.pancakeswap.finance/#/swap?outputCurrency=0xdbaaa36b347d56b77ce0e36f050fceebbf9fbc38">PCS <i class="fa fa-external-link"></i></a></td>
                                <td class="mr-head-right">USDT</td>
                                <td class="mr-head-right">05.25.2021</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

    </div>
</section>





<?php include("footer.php") ?>